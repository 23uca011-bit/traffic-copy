<?php
$con = new mysqli("localhost","root","","loyola");

if($con->connect_error){
    die("Connection Failed: ".$con->connect_error);
}

$search = "";
if(isset($_GET['search'])){
    $search = $_GET['search'];
    $sql = "SELECT * FROM loyolite 
            WHERE Name LIKE '%$search%' 
            OR Dept_no LIKE '%$search%'";
}else{
    $sql = "SELECT * FROM loyolite";
}

$res = $con->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Panel</title>

<style>

body{
font-family:Poppins;
background:#eef2f7;
padding:40px;
}

h1{
text-align:center;
color:#0b3d91;
margin-bottom:30px;
}

.searchbox{
text-align:center;
margin-bottom:25px;
}

.searchbox input{
padding:10px;
width:250px;
border-radius:6px;
border:1px solid #ccc;
}

.searchbox button{
padding:10px 20px;
background:#0b3d91;
color:white;
border:none;
border-radius:6px;
cursor:pointer;
}

table{
width:100%;
border-collapse:collapse;
background:white;
box-shadow:0 8px 20px rgba(0,0,0,.1);
}

th{
background:#0b3d91;
color:white;
padding:10px;
font-size:14px;
}

td{
padding:10px;
border-bottom:1px solid #ddd;
font-size:13px;
text-align:center;
}

tr:hover{
background:#f4f7fc;
}

a.doc{
color:#0b3d91;
font-weight:600;
text-decoration:none;
}

a.doc:hover{
text-decoration:underline;
}

</style>
</head>

<body>

<h1>Loyola Mid-Day Meal Admin Panel</h1>

<div class="searchbox">
<form method="get">
<input type="text" name="search" placeholder="Search by Name or Dept No">
<button type="submit">Search</button>
</form>
</div>

<table>

<tr>
<th>Name</th>
<th>Dept No</th>
<th>Contact</th>
<th>Shift</th>
<th>Status</th>
<th>Documents</th>
</tr>

<?php
while($row=$res->fetch_assoc()){
?>

<tr>

<td><?php echo $row['Name']; ?></td>
<td><?php echo $row['Dept_no']; ?></td>
<td><?php echo $row['Contact_no']; ?></td>
<td><?php echo $row['Shift']; ?></td>
<td><?php echo $row['Status']; ?></td>

<td>

<a class="doc" href="<?php echo $row['Passport_photo']; ?>">Photo</a> |
<a class="doc" href="<?php echo $row['Ration_card']; ?>">Ration</a> |
<a class="doc" href="<?php echo $row['Income_certificate']; ?>">Income</a> |
<a class="doc" href="<?php echo $row['Community_certificate']; ?>">Community</a>

</td>

</tr>

<?php } ?>

</table>

</body>
</html>