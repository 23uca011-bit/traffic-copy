<?php
session_start();

// Only show form if cookie "rct" is not set
if(!isset($_COOKIE["rct"])) {

    // Initialize error variables
    $nerr=$dnerr=$cnerr=$aderr=$mterr=$derr=$serr=$sterr=$rerr=$ferr=$merr=$sberr=$acnerr="";
    $rcerr=$icerr=$ccerr=$idcerr=$dcerr=$pperr=$flerr=$plerr=$sserr=$prlerr="";

    // Validation function
    function val(){
        global $nerr,$dnerr,$cnerr,$aderr,$mterr,$derr,$serr,$sterr,$rerr,$ferr,$merr,$sberr,$acnerr;
        global $rcerr,$icerr,$ccerr,$idcerr,$dcerr,$pperr,$flerr,$plerr,$sserr,$prlerr;

        // Name
        if(empty($_POST["un"])) $nerr="Name can't be empty.";
        else if(strlen($_POST["un"])>30) $nerr="Name too long.";

        // Dept no
        if(empty($_POST["udn"])) $dnerr="Department no cannot be empty";
        else if(!preg_match('/^\d{2}-[a-zA-Z]{3}-\d{3}$/',$_POST["udn"])) $dnerr="Dept no format incorrect";

        // Contact no
        if(empty($_POST["up"])) $cnerr="Contact no cannot be empty";
        else if(!preg_match('/^\d{10}$/',$_POST["up"])) $cnerr="Contact no must be 10 digits";

        // Aadhaar no
        if(empty($_POST["uacn"])) $acnerr="Aadhaar cannot be empty";
        else if(!preg_match('/^\d{12}$/',$_POST["uacn"])) $acnerr="Aadhaar must be 12 digits";

        // Address
        if(empty($_POST["uadd"])) $aderr="Address cannot be empty";
        else if(strlen($_POST["uadd"])>150) $aderr="Address too long";
        else if(strlen($_POST["uadd"])<10) $aderr="Address too short";

        // Mode of Transport
        if(empty($_POST["umot"])) $mterr="Select mode of transport";

        // Distance
        if(!isset($_POST["ud"]) || $_POST["ud"]=="" || $_POST["ud"]<0 || $_POST["ud"]>99) $derr="Invalid distance";

        // Shift
        if(empty($_POST["ush"])) $serr="Select shift";

        // Status
        if(empty($_POST["us"])) $sterr="Select status";

        // Reason
        if(empty($_POST["ur"])) $rerr="Reason cannot be empty";
        else if(strlen($_POST["ur"])>150) $rerr="Reason too long";
        else if(strlen($_POST["ur"])<10) $rerr="Reason too short";

        // Family Details
        if(empty($_POST["ufn"]) || empty($_POST["ufi"]) || empty($_POST["ufo"])) $ferr="Father details incomplete";
        if(empty($_POST["umn"]) || empty($_POST["umi"]) || empty($_POST["umo"])) $merr="Mother details incomplete";
        if(empty($_POST["uns"])) $sberr="Siblings cannot be empty";

        // File uploads
        if(empty($_FILES["urf"]["name"])) $rcerr="Upload Ration card";
        if(empty($_FILES["uif"]["name"])) $icerr="Upload Income certificate";
        if(empty($_FILES["ucf"]["name"])) $ccerr="Upload Community certificate";
        if(empty($_FILES["uidf"]["name"])) $idcerr="Upload ID card";
        if(!empty($_FILES["udf"]["name"]) && $_FILES["udf"]["error"]!=0) $dcerr="Error uploading Death Certificate";
        if(empty($_FILES["upf"]["name"])) $pperr="Upload Passport photo";
        if(empty($_FILES["uprl"]["name"])) $prlerr="Upload Parent Letter";
        if(empty($_FILES["uss"]["name"])) $sserr="Upload Student Sign";
        if(empty($_FILES["ufl"]["name"])) $flerr="Upload Faculty Letter";
        if(empty($_FILES["upl"]["name"])) $plerr="Upload H.O.D Letter";
    }

    // File upload function
    function ful($fn){
        if(isset($_FILES[$fn]) && $_FILES[$fn]["error"]==UPLOAD_ERR_OK){
            $td = "uploads/";
            if (!file_exists($td)) mkdir($td, 0777, true);
            $f = $_FILES[$fn];
            $tf = $td . basename($f["name"]);
            $ft = strtolower(pathinfo($tf, PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','gif'];
            if(!in_array($ft,$allowed)){ echo "Only JPG, JPEG, PNG & GIF allowed."; exit; }
            if(move_uploaded_file($f["tmp_name"],$tf)) return $tf;
        }
        return "";
    }

    if(isset($_POST["urb"])){
        val();
        $errors = array_filter([$nerr,$dnerr,$cnerr,$aderr,$mterr,$derr,$serr,$sterr,$rerr,$ferr,$merr,$sberr,$rcerr,$icerr,$ccerr,$idcerr,$dcerr,$pperr,$prlerr,$sserr,$flerr,$plerr]);
        if(empty($errors)){
            // Store form data
            $rdet = [
                "n"=>$_POST["un"], "dn"=>$_POST["udn"], "pn"=>$_POST["up"], "an"=>$_POST["uacn"], "add"=>$_POST["uadd"],
                "mot"=>$_POST["umot"], "d"=>$_POST["ud"], "sh"=>$_POST["ush"], "st"=>$_POST["us"], "r"=>$_POST["ur"],
                "fn"=>$_POST["ufn"], "fi"=>$_POST["ufi"], "fo"=>$_POST["ufo"],
                "mn"=>$_POST["umn"], "mi"=>$_POST["umi"], "mo"=>$_POST["umo"], "nos"=>$_POST["uns"]
            ];

            // File uploads
            $files = [
                "pp"=>"upf",
                "rc"=>"urf",
                "ic"=>"uif",
                "cc"=>"ucf",
                "dc"=>"udf",
                "idc"=>"uidf",
                "prl"=>"uprl",
                "ss"=>"uss",
                "fl"=>"ufl",
                "pl"=>"upl"
            ];

            foreach($files as $key=>$val) $rdet["file"][$key] = ful($val);

            setcookie("rdet",serialize($rdet),time()+86400*30);

            // Database insert
            $con = new mysqli("localhost","root","","loyola");
            if($con->connect_error) die("DB Connection Failed: ".$con->connect_error);

           $con->query("insert into loyolite (Name,Dept_no,Contact_no,Adhar_no,Address,Mode_of_transport,Distance,Shift,Status,Reason,Father_name,Father_income,Father_occupation,Mother_name,Mother_income,Mother_occupation,No_of_sibling,Overall_income,Passport_photo,Ration_card,Income_certificate,Community_certificate,Death_certificate,Id_card,Parent_letter,Student_sign,Faculty_letter,HOD_permit,Approvel_status)values('{$rdet["n"]}','{$rdet["dn"]}','{$rdet["pn"]}','{$rdet["an"]}','{$rdet["add"]}','{$rdet["mot"]}','{$rdet["d"]}','{$rdet["sh"]}','{$rdet["st"]}','{$rdet["r"]}','{$rdet["fn"]}','{$rdet["fi"]}','{$rdet["fo"]}','{$rdet["mn"]}','{$rdet["mi"]}','{$rdet["mo"]}','{$rdet["nos"]}','{$rdet["oi"]}','{$rdet["file"]["pp"]}','{$rdet["file"]["rc"]}','{$rdet["file"]["ic"]}','{$rdet["file"]["cc"]}','{$rdet["file"]["dc"]}','{$rdet["file"]["idc"]}','{$rdet["file"]["prl"]}','{$rdet["file"]["ss"]}','{$rdet["file"]["fl"]}','{$rdet["file"]["pl"]}','{$rdet["apst"]}')");

            $con->close();

            echo "<script>alert('Successfully Registered.');window.location='nhh.php';</script>";
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Mid-Day Meal Registration</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">

<style>
/* ===== GLOBAL ===== */
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Poppins',sans-serif;background:linear-gradient(120deg,#edf2f7,#d7e1ec);color:#333;}
.topbar{width:100%;background:#0b3d91;color:white;display:flex;justify-content:space-between;align-items:center;padding:14px 40px;box-shadow:0 4px 10px rgba(0,0,0,.2);}
.logo{font-size:20px;font-weight:700;letter-spacing:1px;}
.nav{font-size:15px;font-weight:500;}
.progress-container{width:100%;height:6px;background:#dfe6ef;}
.progress-bar{width:70%;height:6px;background:linear-gradient(90deg,#0b3d91,#004aad);}
h1{text-align:center;font-size:2.6rem;font-weight:900;color:#0b3d91;margin:40px 0 25px 0;}
form{max-width:960px;margin:auto;background:#fff;padding:45px 55px;border-radius:16px;box-shadow:0 18px 40px rgba(0,0,0,.15);}
section{margin-bottom:40px;padding:28px 32px;background:#f7f9fc;border-left:6px solid #0b3d91;border-radius:10px;position:relative;}
section:nth-of-type(1)::before{content:"STEP 1";position:absolute;right:25px;top:18px;font-size:12px;font-weight:700;background:#0b3d91;color:white;padding:4px 10px;border-radius:20px;}
section:nth-of-type(2)::before{content:"STEP 2";position:absolute;right:25px;top:18px;font-size:12px;font-weight:700;background:#0b3d91;color:white;padding:4px 10px;border-radius:20px;}
section:nth-of-type(3)::before{content:"STEP 3";position:absolute;right:25px;top:18px;font-size:12px;font-weight:700;background:#0b3d91;color:white;padding:4px 10px;border-radius:20px;}
h2{font-size:1.5rem;font-weight:800;color:#0b3d91;margin-bottom:20px;padding-bottom:8px;border-bottom:2px solid #0b3d91;}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:25px 50px;position:relative;}
.form-grid::before{content:"";position:absolute;left:50%;top:0;bottom:0;width:1px;background:#d5dde8;}
label{display:flex;flex-direction:column;font-size:15px;font-weight:600;color:#0b3d91;padding-bottom:12px;border-bottom:1px solid #e4e8ef;}
.form-grid label, section:nth-of-type(2) > label{position:relative;}
.form-grid label::before, section:nth-of-type(2) > label::before{content:"*";color:#d93025;font-weight:700;font-size:16px;position:absolute;left:-10px;top:2px;}
input[type=text], input[type=number], select, textarea{width:100%;padding:12px 14px;margin-top:6px;border-radius:8px;border:1.5px solid #ccd2da;font-size:14px;background:white;transition:.25s;}
input:focus, select:focus, textarea:focus{border-color:#0b3d91;box-shadow:0 0 6px rgba(11,61,145,.25);outline:none;transform:scale(1.02);}
textarea{resize:none;height:70px;}
input[type=file]{margin-top:8px;padding:14px;background:#f8fafc;border:2px dashed #bfc9d9;border-radius:10px;font-size:13px;cursor:pointer;transition:all .3s ease;color:#333;font-weight:500;}
input[type=file]:hover{border-color:#0b3d91;background:#eef3fb;}
input[type=file]:focus{outline:none;border-color:#004aad;box-shadow:0 0 8px rgba(11,61,145,.25);}
input[type=file]::file-selector-button{background:linear-gradient(90deg,#0b3d91,#004aad);color:white;border:none;padding:8px 16px;border-radius:6px;margin-right:12px;font-size:13px;font-weight:600;cursor:pointer;transition:.3s;}
input[type=file]::file-selector-button:hover{background:linear-gradient(90deg,#ffd100,#ffc107);color:#0b3d91;}
.family-details{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:8px;}
.err{color:#d93025;font-size:12px;margin-top:4px;}
input[type=submit]{display:block;margin:40px auto 0;padding:16px 60px;font-size:17px;font-weight:700;border:none;border-radius:10px;cursor:pointer;background:linear-gradient(90deg,#0b3d91,#004aad);color:white;transition:.3s;box-shadow:0 8px 20px rgba(0,0,0,.2);}
input[type=submit]:hover{background:linear-gradient(90deg,#ffd100,#ffc107);color:#0b3d91;transform:translateY(-2px);}
@media(max-width:900px){.form-grid{grid-template-columns:1fr;}.form-grid::before{display:none;}.family-details{grid-template-columns:1fr;}}
</style>
</head>
<body>

<div class="topbar">
<div class="logo">Loyola College Portal</div>
<div class="nav">Mid-Day Meal Registration</div>
</div>

<div class="progress-container">
<div class="progress-bar"></div>
</div>

<h1>Loyola Mid-Day Meal Registration</h1>

<form method="post" action="" enctype="multipart/form-data">

<!-- Student Details -->
<section>
<h2>Student Details</h2>
<div class="form-grid">
<label>Name: <input type="text" name="un" placeholder="Name"><span class="err"><?php echo $nerr;?></span></label>
<label>Department No: <input type="text" name="udn" placeholder="23-UCA-024"><span class="err"><?php echo $dnerr;?></span></label>
<label>Contact No: <input type="number" name="up" placeholder="10 digit contact"><span class="err"><?php echo $cnerr;?></span></label>
<label>Aadhaar No: <input type="text" name="uacn" placeholder="12 digit Aadhaar"><span class="err"><?php echo $acnerr;?></span></label>
<label>Address: <textarea name="uadd" placeholder="Full Address"></textarea><span class="err"><?php echo $aderr;?></span></label>
<label>Mode of Transport:
<select name="umot">
<option value="">Select</option>
<option value="Bus">Bus</option>
<option value="Train">Train</option>
<option value="Car">Car</option>
<option value="Bike">Bike</option>
<option value="Bicycle">Bicycle</option>
<option value="Walk">Walk</option>
<option value="Bus&Train">Bus&Train</option>
</select>
<span class="err"><?php echo $mterr;?></span>
</label>
<label>Distance (km): <input type="number" name="ud"><span class="err"><?php echo $derr;?></span></label>
<label>Shift:
<select name="ush">
<option value="">Select</option>
<option value="I-(F/N)">I</option>
<option value="II-(A/N)">II</option>
</select>
<span class="err"><?php echo $serr;?></span>
</label>
<label>Status:
<div>
<input type="radio" name="us" value="Orphan">Orphan
<input type="radio" name="us" value="Semi-Orphan">Semi-Orphan
<input type="radio" name="us" value="None">None
</div>
<span class="err"><?php echo $sterr;?></span>
</label>
<label>Reason: <textarea name="ur"></textarea><span class="err"><?php echo $rerr;?></span></label>
</div>
</section>

<!-- Family Details -->
<section>
<h2>Family Details</h2>
<label>Father:
<div class="family-details">
<input type="text" name="ufn" placeholder="Name">
<input type="number" name="ufi" placeholder="Income">
<input type="text" name="ufo" placeholder="Occupation">
</div>
<span class="err"><?php echo $ferr;?></span>
</label>
<label>Mother:
<div class="family-details">
<input type="text" name="umn" placeholder="Name">
<input type="number" name="umi" placeholder="Income">
<input type="text" name="umo" placeholder="Occupation">
</div>
<span class="err"><?php echo $merr;?></span>
</label>
<label>Siblings: <input type="number" name="uns"><span class="err"><?php echo $sberr;?></span></label>
</section>

<!-- Documents -->
<section>
<h2>Documents</h2>
<div class="form-grid">
<label>Passport Photo: <input type="file" name="upf"><span class="err"><?php echo $pperr;?></span></label>
<label>Ration Card: <input type="file" name="urf"><span class="err"><?php echo $rcerr;?></span></label>
<label>Income Certificate: <input type="file" name="uif"><span class="err"><?php echo $icerr;?></span></label>
<label>Community Certificate: <input type="file" name="ucf"><span class="err"><?php echo $ccerr;?></span></label>
<label>Death Certificate (if applicable): <input type="file" name="udf"><span class="err"><?php echo $dcerr;?></span></label>
<label>ID Card: <input type="file" name="uidf"><span class="err"><?php echo $idcerr;?></span></label>
<label>Parent Letter: <input type="file" name="uprl"><span class="err"><?php echo $prlerr;?></span></label>
<label>Student Sign: <input type="file" name="uss"><span class="err"><?php echo $sserr;?></span></label>
<label>Faculty Letter: <input type="file" name="ufl"><span class="err"><?php echo $flerr;?></span></label>
<label>H.O.D Letter: <input type="file" name="upl"><span class="err"><?php echo $plerr;?></span></label>
</div>
</section>

<input type="submit" name="urb" value="Register">
</form>
</body>
</html>