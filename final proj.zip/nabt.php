
<?php
session_start();

if (isset($_COOKIE["rct"]) ? $_COOKIE["rct"] : 1) {

$rdet = unserialize($_COOKIE["rdet"]);
$totalIncome = $rdet["fi"] + $rdet["mi"];

echo '

<style>

body{
font-family:"Poppins",Arial;
margin:0;
background:linear-gradient(135deg,#eef2ff,#f9fbff);
}

/* HEADER */

.header{
background:#0b3d91;
color:white;
padding:18px 40px;
display:flex;
justify-content:space-between;
align-items:center;
border-bottom:4px solid #ffc107;
}

.header h1{
margin:0;
font-size:22px;
}

/* NAVBAR */

.navbar{
background:#004aad;
padding:10px 40px;
}

.navbar a{
color:white;
margin-right:25px;
text-decoration:none;
font-weight:500;
}

.navbar a:hover{
color:#ffc107;
}

/* MAIN CONTAINER */

.container{
width:1100px;
margin:40px auto;
background:white;
border-radius:10px;
box-shadow:0 10px 30px rgba(0,0,0,0.15);
overflow:hidden;
}

/* PROFILE */

.profile{
display:flex;
padding:30px;
border-bottom:1px solid #eee;
}

.profile img{
width:150px;
height:150px;
border-radius:50%;
border:4px solid #0b3d91;
object-fit:cover;
margin-right:30px;
}

.profile-info h2{
margin:0;
color:#0b3d91;
}

.profile-info p{
margin:6px 0;
font-weight:500;
}

/* DASHBOARD STATS */

.stats{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
gap:20px;
padding:25px;
background:#f6f8ff;
}

.stat-card{
background:#0b3d91;
color:white;
padding:20px;
border-radius:8px;
text-align:center;
box-shadow:0 5px 15px rgba(0,0,0,0.15);
}

.stat-card h4{
margin:0;
font-weight:500;
}

.stat-card p{
font-size:20px;
font-weight:700;
margin-top:5px;
}

/* TABLE */

table{
width:100%;
border-collapse:collapse;
}

th{
background:#0b3d91;
color:white;
padding:12px;
}

td{
padding:12px;
border-bottom:1px solid #eee;
}

.label{
font-weight:600;
color:#0b3d91;
width:35%;
}

/* DOCUMENTS */

.docs{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
gap:20px;
padding:30px;
}

.doc{
border:1px solid #e5e5e5;
border-radius:8px;
padding:15px;
text-align:center;
background:#fafaff;
transition:0.3s;
}

.doc:hover{
transform:translateY(-5px);
box-shadow:0 5px 20px rgba(0,0,0,0.15);
}

.doc img{
width:100%;
height:150px;
object-fit:contain;
border:1px solid #ddd;
background:white;
}

.doc-title{
margin-top:8px;
font-weight:600;
color:#0b3d91;
}

.download{
display:inline-block;
margin-top:8px;
background:#0b3d91;
color:white;
padding:6px 12px;
text-decoration:none;
border-radius:4px;
font-size:13px;
}

.download:hover{
background:#ffc107;
color:#0b3d91;
}

/* FOOTER */

.footer{
background:#0b3d91;
color:white;
text-align:center;
padding:15px;
border-top:4px solid #ffc107;
font-size:14px;
}

</style>

<div class="header">
<h1>Loyola College Chennai - Student ERP Portal</h1>
</div>

<div class="navbar">
<a href="nhh.php">Home</a>
<a href="#">Profile</a>
<a href="#">Documents</a>
<a href="nid.php">ID Card</a>
</div>

<div class="container">

<div class="profile">
<img src="'.$rdet["file"]["pp"].'">

<div class="profile-info">
<h2>'.$rdet["n"].'</h2>
<p><b>Department No:</b> '.$rdet["dn"].'</p>
<p><b>Phone:</b> '.$rdet["pn"].'</p>
<p><b>Status:</b> '.$rdet["st"].'</p>
</div>
</div>

<div class="stats">

<div class="stat-card">
<h4>Distance</h4>
<p>'.$rdet["d"].' km</p>
</div>

<div class="stat-card">
<h4>Siblings</h4>
<p>'.$rdet["nos"].'</p>
</div>

<div class="stat-card">
<h4>Total Family Income</h4>
<p>'.$totalIncome.'</p>
</div>

<div class="stat-card">
<h4>Shift</h4>
<p>'.$rdet["sh"].'</p>
</div>

</div>

<table>

<tr><th colspan="2">Student Information</th></tr>

<tr><td class="label">Aadhar Number</td><td>'.$rdet["an"].'</td></tr>
<tr><td class="label">Address</td><td>'.$rdet["add"].'</td></tr>
<tr><td class="label">Mode of Transport</td><td>'.$rdet["mot"].'</td></tr>
<tr><td class="label">Reason</td><td>'.$rdet["r"].'</td></tr>

<tr><td class="label">Father Name</td><td>'.$rdet["fn"].'</td></tr>
<tr><td class="label">Father Income</td><td>'.$rdet["fi"].'</td></tr>
<tr><td class="label">Father Occupation</td><td>'.$rdet["fo"].'</td></tr>

<tr><td class="label">Mother Name</td><td>'.$rdet["mn"].'</td></tr>
<tr><td class="label">Mother Income</td><td>'.$rdet["mi"].'</td></tr>
<tr><td class="label">Mother Occupation</td><td>'.$rdet["mo"].'</td></tr>

</table>

<div class="docs">

<div class="doc">
<img src="'.$rdet["file"]["pp"].'">
<div class="doc-title">Passport Photo</div>
<a class="download" href="'.$rdet["file"]["pp"].'" download>Download</a>
</div>

<div class="doc">
<img src="'.$rdet["file"]["rc"].'">
<div class="doc-title">Ration Card</div>
<a class="download" href="'.$rdet["file"]["rc"].'" download>Download</a>
</div>

<div class="doc">
<img src="'.$rdet["file"]["ic"].'">
<div class="doc-title">Income Certificate</div>
<a class="download" href="'.$rdet["file"]["ic"].'" download>Download</a>
</div>

<div class="doc">
<img src="'.$rdet["file"]["cc"].'">
<div class="doc-title">Community Certificate</div>
<a class="download" href="'.$rdet["file"]["cc"].'" download>Download</a>
</div>

'.(isset($rdet["file"]["dc"])?
'<div class="doc">
<img src="'.$rdet["file"]["dc"].'">
<div class="doc-title">Death Certificate</div>
<a class="download" href="'.$rdet["file"]["dc"].'" download>Download</a>
</div>'
:'').'

<div class="doc">
<img src="'.$rdet["file"]["idc"].'">
<div class="doc-title">ID Card</div>
<a class="download" href="'.$rdet["file"]["idc"].'" download>Download</a>
</div>

<div class="doc">
<img src="'.$rdet["file"]["prl"].'">
<div class="doc-title">Parent Approval Letter</div>
<a class="download" href="'.$rdet["file"]["prl"].'" download>Download</a>
</div>

<div class="doc">
<img src="'.$rdet["file"]["ss"].'">
<div class="doc-title">Student Signature</div>
<a class="download" href="'.$rdet["file"]["ss"].'" download>Download</a>
</div>

<div class="doc">
<img src="'.$rdet["file"]["fl"].'">
<div class="doc-title">Faculty Letter</div>
<a class="download" href="'.$rdet["file"]["fl"].'" download>Download</a>
</div>

<div class="doc">
<img src="'.$rdet["file"]["pl"].'">
<div class="doc-title">HOD Permit</div>
<a class="download" href="'.$rdet["file"]["pl"].'" download>Download</a>
</div>

</div>

</div>

<div class="footer">
© '.date("Y").' Loyola College Chennai | Student ERP Portal
</div>

';

} else {

echo '<center style="margin-top:120px;font-family:Poppins">

<h2>Oops...! You are not registered yet.</h2>

<p>Please register to access the portal.</p>

<a href="pracmmh.php">Register Now</a><br><br>

<input type="button" value="Back to Home" onclick="window.location=\'mmhh.php\'">

</center>';

}

?>

