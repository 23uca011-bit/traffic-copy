
<?php
session_start();

if (isset($_COOKIE["rct"])?1:1){

$rdet = unserialize($_COOKIE["rdet"]);

$dn = $rdet["dn"];
$gl = (substr($dn,3,1)=="U"?"UG":"PG");

switch(substr($dn,3,3)){
case "UCA": $dpt="Computer Science"; $cs="BCA"; break;
case "UCS": $dpt="Computer Science"; $cs="B.Sc CS"; break;
case "UCH": $dpt="Chemistry"; $cs="B.Sc Chemistry"; break;
case "UPH": $dpt="Physics"; $cs="B.Sc Physics"; break;
case "UFR": $dpt="French"; $cs="BA French"; break;
case "UHT": $dpt="History"; $cs="BA History"; break;
case "UST": $dpt="Statistics"; $cs="BA Statistics"; break;
default: $dpt="Unknown"; $cs="Unknown";
}

$pdet=[
"n"=>$rdet["n"]??"Unknown",
"dpt"=>$dpt,
"gl"=>$gl,
"y"=>((int)date("Y")%100-(int)substr($dn,0,2)),
"rn"=>(int)substr($dn,7),
"b"=>(substr(date("Y"),0,2).substr($dn,0,2))."-".($gl=="UG"?((int)substr($dn,0,2)+3):((int)substr($dn,0,2)+2)),
"cs"=>($gl=="PG"?"M".substr($cs,1):$cs),
"photo"=>$rdet["file"]["pp"]
];

setcookie("pdet",serialize($pdet),time()+3600*24);
?>

<!DOCTYPE html>
<html>
<head>

<title>Loyola College Student Portal</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

<style>

body{
font-family:'Poppins',sans-serif;
margin:0;
background:linear-gradient(135deg,#eef4ff,#f8fbff);
}

/* HEADER */

.header{
background:#0b3d91;
color:yellow;
padding:15px 40px;
display:flex;
align-items:center;
border-bottom:4px solid #ffc107;
}

.header img{
height:55px;
margin-right:15px;
border-radius:50%;
border:4px solid gold;
}

.header h1{
font-size:22px;
margin:0;
font-weight:600;
}

/* NAVBAR */

.navbar{
background:#004aad;
padding:12px 40px;
border-bottom:3px solid #ffc107;
}

.navbar a{
color:yellow;
margin-right:30px;
text-decoration:none;
font-weight:500;
padding:6px 10px;
border-radius:5px;
}

.navbar a:hover{
background:#ffc107;
color:#0b3d91;
}

/* MAIN CONTAINER */

.container{
width:1000px;
margin:40px auto;
background:white;
border-radius:12px;
box-shadow:0 12px 30px rgba(0,0,0,0.12);
overflow:hidden;
border:2px solid #e0e6ff;
}

/* PROFILE HEADER */

.profile-header{
display:flex;
align-items:center;
padding:35px;
border-bottom:2px solid #e6e6e6;
}

.profile-photo img{
width:150px;
height:150px;
border-radius:50%;
border:5px solid #0b3d91;
object-fit:cover;
box-shadow:0 5px 15px rgba(0,0,0,0.2);
}

.profile-info{
margin-left:30px;
}

.profile-info h2{
margin:0;
font-size:28px;
color:#0b3d91;
font-weight:700;
}

.profile-info p{
margin:5px 0;
font-weight:500;
color:#555;
}

/* QUICK STATS */

.stats{
display:flex;
background:linear-gradient(90deg,#0b3d91,#004aad);
color:white;
text-align:center;
border-bottom:5px solid yellow;
border-top:5px solid gold;

}

.stats div{
flex:1;
padding:20px;
border-right:5px solid rgba(255,255,255,0.3);
}

.stats div:last-child{
border-right:none;
}

.stats h4{
color:gold;
margin:0;
font-weight:500;
font-size:14px;
}

.stats p{
margin-top:5px;
font-size:20px;
font-weight:700;
}

/* CARDS */

.cards{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
gap:25px;
padding:35px;
}

.card{
background:linear-gradient(135deg,#0b3d91,#004aad);
color:white;
padding:25px;
border-radius:10px;
text-align:center;
box-shadow:0 8px 20px rgba(0,0,0,0.1);
transition:0.3s;
border:2px solid transparent;
}

.card:hover{
transform:translateY(-5px);
border:4px solid yellow;
box-shadow:0 10px 25px rgba(0,0,0,0.2);
}

.card h4{
margin:0;
color:gold;
font-weight:500;
}

.card p{
margin-top:10px;
font-size:18px;
font-weight:700;
}

/* BUTTON */

.btn{
display:block;
width:200px;
margin:10px auto 40px auto;
text-align:center;
padding:12px;
background:#0b3d91;
color:white;
text-decoration:none;
font-weight:600;
border-radius:8px;
transition:0.3s;
}

.btn:hover{
background:#ffc107;
color:#0b3d91;
}

/* FOOTER */

.footer{
background:#0b3d91;
color:white;
text-align:center;
padding:18px;
margin-top:40px;
border-top:4px solid #ffc107;
font-size:14px;
}

.footer span{
color:#ffc107;
font-weight:600;
}

</style>

</head>

<body>

<div class="header">
<img src="logo.png">
<h1>Loyola College Chennai - Student Portal</h1>
</div>

<div class="navbar">
<a href="nhh.php">Home</a>
<a href="#">Profile</a>
<a href="#">Documents</a>
<a href="#">Logout</a>
</div>

<div class="container">

<div class="profile-header">

<div class="profile-photo">
<img src="<?php echo $pdet['photo']; ?>">
</div>

<div class="profile-info">
<h2><?php echo strtoupper($pdet['n']); ?></h2>
<p><b><?php echo $rdet['dn']; ?></p>
<p><?php echo $pdet['gl']." - ".$pdet['dpt']; ?></b></p>
</div>

</div>

<div class="stats">

<div>
<h4>Course</h4>
<p><?php echo $pdet['cs']; ?></p>
</div>

<div>
<h4>Year</h4>
<p><?php echo $pdet['y']; ?></p>
</div>

<div>
<h4>Roll No</h4>
<p><?php echo $pdet['rn']; ?></p>
</div>

<div>
<h4>Batch</h4>
<p><?php echo $pdet['b']; ?></p>
</div>

</div>

<div class="cards">

<div class="card">
<h4>Department</h4>
<p><?php echo $pdet['dpt']; ?></p>
</div>

<div class="card">
<h4>Shift</h4>
<p><?php echo $rdet['sh']; ?></p>
</div>

<div class="card">
<h4>Status</h4>
<p>Active</p>
</div>

<div class="card">
<h4>Graduation Level</h4>
<p><?php echo $pdet['gl']; ?></p>
</div>

</div>

<a href="nhh.php" class="btn">Back to Home</a>

</div>

<div class="footer">
© <?php echo date("Y"); ?> <span>Loyola College Chennai</span> | Student Portal System  
</div>

</body>
</html>

<?php } ?>

