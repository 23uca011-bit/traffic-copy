<?php
session_start();

if (isset($_COOKIE["rct"]) ? 1 : 1) {
    $rdet = unserialize($_COOKIE["rdet"]);
?>

<!DOCTYPE html>
<html>
<head>
<title>Midday Meals ID Card - Loyola College</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Poppins', sans-serif;
    background: #eef2ff;
    margin: 0;
    text-align: center;
}

/* HEADER */
.header {
    background:#0b3d91;
    color:white;
    padding:15px;
    font-weight:600;
    border-bottom:4px solid #ffc107;
}

/* ID CARD CONTAINER */
.id-container {
    display: flex;
    justify-content: center;
    flex-wrap: wrap;
    margin-top: 50px;
    gap: 40px;
}

/* ID CARD */
.id-card {
    width: 360px;
    height: 220px;
    background: white;
    border-radius: 12px;
    border: 3px solid #0b3d91;
    box-shadow: 0 12px 25px rgba(0,0,0,0.2);
    overflow: hidden;
    text-align: center;
    position: relative;
}

/* ID TITLE */
.id-title {
    background: #ffc107;
    color: #0b3d91;
    padding: 6px;
    font-weight: 700;
    font-size: 14px;
    letter-spacing: 1px;
}

/* PHOTO + NAME */
.photo {
    margin-top: 15px;
}
.photo img {
    width: 90px;
    height: 90px;
    border-radius: 50%;
    border: 3px solid #0b3d91;
    object-fit: cover;
}

.name {
    margin-top: 8px;
    font-size: 18px;
    font-weight: 700;
    color: #0b3d91;
}

/* DETAILS */
.details {
    padding: 5px 15px;
    text-align: left;
}
.details p {
    margin: 3px 0;
    font-weight: 500;
    font-size: 13px;
    color: #444;
}

/* FOOTER */
.id-footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    background: #f6f8ff;
    font-size: 12px;
    padding: 4px 0;
    border-top: 1px solid #ddd;
    font-weight: 500;
}

/* BUTTON */
.btn {
    display: inline-block;
    margin-top: 30px;
    padding: 10px 18px;
    background: #0b3d91;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: 600;
}
.btn:hover {
    background: #ffc107;
    color: #0b3d91;
}

/* PRINT STYLE */
@media print {
    body { background: white; }
    .header, .btn { display: none; }
    .id-card { box-shadow: none; margin-top: 0; }
}
</style>
</head>
<body>

<div class="header">
<h2>Loyola College Chennai</h2>
</div>

<div class="id-container">

<!-- FRONT SIDE -->
<div class="id-card">
<div class="id-title">MIDDAY MEALS ID</div>

<div class="photo">
<img src="<?php echo $rdet["file"]["pp"]; ?>">
</div>

<div class="name">
<?php echo strtoupper($rdet["n"]); ?>
</div>

<div class="details">
<p><b>Department No:</b> <?php echo $rdet["dn"]; ?></p>
<p><b>Shift:</b> <?php echo $rdet["sh"]; ?></p>
<p><b>Status:</b> <?php echo $rdet["st"]; ?></p>
</div>

<div class="id-footer">Valid Midday Meals Beneficiary - Loyola College</div>
</div>

<!-- BACK SIDE -->
<div class="id-card">
<div class="id-title">MIDDAY MEALS ID</div>

<div class="details" style="margin-top:20px;">
<p><b>Father Name:</b> <?php echo $rdet["fn"]; ?></p>
<p><b>Mother Name:</b> <?php echo $rdet["mn"]; ?></p>
<p><b>Overall Income:</b> <?php echo ($rdet["fi"]+$rdet["mi"]); ?></p>
<p><b>Phone:</b> <?php echo $rdet["pn"]; ?></p>
<p><b>Address:</b> <?php echo $rdet["add"]; ?></p>

</div>

<div class="id-footer">Keep this card safe. College copy only.</div>
</div>

</div>

<button class="btn" onclick="window.print()">Print / Download ID</button>

</body>
</html>

<?php
} else {
echo "<center style='margin-top:120px;font-family:Poppins'>
<h2>You are not registered.</h2>
<a href='pracmmh.php'>Register Now</a>
</center>";
}
?>

