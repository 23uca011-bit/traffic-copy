<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>

<title>Loyola College | Mid-Day Meals Portal</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
<!-- Font Awesome for icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

/* GLOBAL */
body{
  margin:0;
  font-family:'Poppins',sans-serif;
  background:#f5f7fb;
}

/* HEADER */
.header{
  background:#0b3d91;
  color:white;
  display:flex;
  align-items:center;
  padding:15px 40px;
}
.logo{
  height:65px;
  margin-right:20px;
}
.title{
  font-size:26px;
  font-weight:600;
}
.subtitle{
  font-size:14px;
  opacity:0.9;
}

/* NAVBAR */
.navbar{
  background:#0b3d91;
  box-shadow:0 3px 8px rgba(0,0,0,0.2);
}
.navbar ul{
  margin:0;
  padding:0;
  display:flex;
  list-style:none;
}
.navbar li{
  position:relative;
}
.navbar a{
  display:block;
  padding:16px 22px;
  color:yellow;
  text-decoration:none;
  transition:0.3s;
  font-size:15px;
  font-weight:bold;
}
.navbar a:hover{
  background:#ffd100;
  color:#0b3d91;
}
.right{
  margin-left:auto;
}

/* HERO */
.hero{
  background:linear-gradient(yellow,gold,blue),url("campus.jpg");
  background-size:cover;
  color:black;
  text-align:center;
  padding:120px 40px;
}
.hero h1{
  font-size:42px;
  margin-bottom:10px;
}
.hero p{
  font-size:18px;
  margin-bottom:30px;
}
.btn{
  background:#ffd100;
  color:#0b3d91;
  padding:14px 30px;
  border-radius:30px;
  text-decoration:none;
  font-weight:600;
  transition:0.3s;
}
.btn:hover{
  background:white;
}

/* WELCOME */
.welcome{
  padding:50px;
  text-align:center;
  background:white;
}

/* DASHBOARD STATS */
.stats{
  display:flex;
  justify-content:center;
  flex-wrap:wrap;
  gap:25px;
  padding:40px;
}
.stat-box{
  background:white;
  width:220px;
  padding:25px;
  border-radius:10px;
  box-shadow:0 4px 12px rgba(0,0,0,0.1);
  text-align:center;
}
.stat-box h2{
  color:#0b3d91;
  margin:0;
}

/* PORTAL SERVICES */
.services{
  padding:60px 80px;
  background:#e8f0ff;
}
.services h2{
  text-align:center;
  color:#0b3d91;
}
.grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
  gap:25px;
  margin-top:40px;
}
.service-card{
  background:white;
  padding:25px;
  border-radius:10px;
  box-shadow:0 4px 12px rgba(0,0,0,0.1);
  transition:0.3s;
  text-align:center;
}
.service-card:hover{
  transform:translateY(-8px);
  background:#ffd100;
  color:#0b3d91;
}
.service-card .icon{
  font-size:40px;
  margin-bottom:10px;
  color:#0b3d91;
}

/* ANNOUNCEMENTS */
.announcements{
  padding:50px;
  text-align:center;
}
.notice{
  background:#fff8cc;
  border-left:6px solid #ffd100;
  padding:20px;
  margin:20px auto;
  width:60%;
}

/* QUICK ACTIONS */
.actions{
  padding:70px 80px;
  background:#f5f7fb;
  text-align:center;
}
.actions h2{
  color:#0b3d91;
  margin-bottom:35px;
}
.action-grid{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
  gap:25px;
  max-width:900px;
  margin:auto;
}
.action-card{
  background:white;
  padding:30px;
  border-radius:12px;
  text-decoration:none;
  color:#333;
  box-shadow:0 4px 14px rgba(0,0,0,0.1);
  transition:0.3s;
  display:block;
}
.action-card:hover{
  transform:translateY(-6px);
  background:#ffd100;
  color:#0b3d91;
}
.action-card .icon{
  font-size:35px;
  margin-bottom:10px;
}
.action-card h3{
  margin:10px 0 8px;
  color:#0b3d91;
}
.action-card p{
  font-size:14px;
}

/* FOOTER */
.footer{
  background:#0b3d91;
  color:white;
  text-align:center;
  padding:35px;
  margin-top:40px;
}
.footer small{
  opacity:0.8;
}

</style>

</head>

<body>

<!-- HEADER -->
<div class="header">
<img src="logo.png" class="logo">
<div>
<div class="title">Loyola College, Chennai</div>
<div class="subtitle">Mid-Day Meals Online Registration System</div>
</div>
</div>

<!-- NAVBAR -->
<div class="navbar">
<ul>
<li><a href="#">Home</a></li>
<li><a href="pracmmh.php">Student Registration</a></li>
<li><a href="mmph.php">My Profile</a></li>
<li><a href="mmc.php">Meal Services</a></li>
<li><a href="#contact">Contact</a></li>
<li class="right">
<a href="#" onclick="if(confirm('Logout?')) window.location='mmlop.php';return false;">Logout</a>
</li>
</ul>
</div>

<!-- HERO -->
<div class="hero">
<h1>Loyola Mid-Day Meals Management System</h1>
<p>Digital platform for efficient registration and meal management for Loyola students.</p>
<a class="btn" href="pracmmh.php">Register for Meals</a>
</div>

<!-- WELCOME -->
<div class="welcome">
<?php
// $sidet=unserialize($_COOKIE["sidet"]);
echo "<h2>Welcome ".(isset($sidet["n"])?$sidet["n"]:"Student")."</h2>";
?>
<p>Access all Mid-Day Meal services through this student portal.</p>
</div>

<!-- DASHBOARD STATS -->
<div class="stats">
<div class="stat-box">
<h2>1200+</h2>
<p>Registered Students</p>
</div>
<div class="stat-box">
<h2>850</h2>
<p>Meals Served Today</p>
</div>
<div class="stat-box">
<h2>25</h2>
<p>Departments Covered</p>
</div>
<div class="stat-box">
<h2>100%</h2>
<p>Digital Management</p>
</div>
</div>

<!-- PORTAL SERVICES -->
<div class="services">
<h2>Portal Services</h2>
<div class="grid">
<div class="service-card">
<div class="icon"><i class="fas fa-user-plus"></i></div>
<h3>Student Registration</h3>
<p>Register for the Mid-Day Meal scheme.</p>
</div>

<div class="service-card">
<div class="icon"><i class="fas fa-user-circle"></i></div>
<h3>Profile Management</h3>
<p>Update student details.</p>
</div>

<div class="service-card">
<div class="icon"><i class="fas fa-utensils"></i></div>
<h3>Meal Booking</h3>
<p>Request or cancel daily meals.</p>
</div>

<div class="service-card">
<div class="icon"><i class="fas fa-tachometer-alt"></i></div>
<h3>Admin Monitoring</h3>
<p>Manage student records.</p>
</div>

<div class="service-card">
<div class="icon"><i class="fas fa-file-alt"></i></div>
<h3>Reports</h3>
<p>View meal distribution reports.</p>
</div>

</div>
</div>

<!-- ANNOUNCEMENTS -->
<div class="announcements">
<h2>Announcements</h2>
<div class="notice">
Meal registration deadline for this semester ends next Friday.
</div>
<div class="notice">
Students must carry their ID card for meal verification.
</div>
</div>

<!-- QUICK ACTION -->
<div class="actions">
<h2>Quick Actions</h2>
<div class="action-grid">
<a href="npracmmh.php" class="action-card">
<div class="icon"><i class="fas fa-pen-square"></i></div>
<h3>Register</h3>
<p>Apply for the Mid-Day Meal program.</p>
</a>

<a href="mmph.php" class="action-card">
<div class="icon"><i class="fas fa-user"></i></div>
<h3>My Profile</h3>
<p>View and update your student details.</p>
</a>

<a href="mmc.php" class="action-card">
<div class="icon"><i class="fas fa-utensils"></i></div>
<h3>Meal Services</h3>
<p>Book or manage your daily meals.</p>
</a>
</div>
</div>

<!-- FOOTER -->
<div class="footer">
<p>Mid-Day Meals Online Registration System</p>
<small>© 2026 Loyola College, Chennai</small>
</div>

</body>
</html>