<style>.err{color:red;}</style>
<script>
function dsp(){
alert('JESUS LOVES YOU');
function pgf(){
let gp="",parr=[Math.random()*10+48,Math.random()*26+65,Math.random()*15+33,Math.random()*26+98];
for(let i=parr.length-1;i>-1;i--){
let j=Math.floor(Math.random()*i);
[parr[i],parr[j]]=[parr[j],parr[i]];
gp+=String.fromCharCode(Math.floor(parr[i]));}
return gp;}
let gp="";
gp=pgf()+pgf();
document.getElementById('vup').value=document.getElementById('vucp').value=gp;
alert('suggested password:\n'+gp);
document.getElementById('vp').innerText="suggested password: "+gp;}
</script>

<?php
session_start();
if(isset($_SESSION["vsb"])){
$vperr=$vcperr="";
//validation function
function val(){
global $vperr,$vcperr;
//Password
$up=$_POST["vup"];
if(empty($up))
$vperr="Password cannot be empty";
else if(strlen($up)<8||strlen($up)>8)
$vperr="Password must contain 8 characters.";
else if(!(preg_match('/\d/',$up)&&preg_match('/[a-zA-Z]/',$up)&&preg_match('/[^a-zA-Z0-9]/',$up))) 
$vperr="Password must contain a number,alphabet and symbol.";
//Confirm Password
if(empty($_POST["vucp"]))
$vcperr="Confirm Password cannot be empty";
else if($_POST["vucp"]!=$_POST["vucp"])
$vcperr="Confirm Password must be same as Password.";}


//calling validation function
if(isset($_POST["cps"]))
val();
//redirecting
if(empty($vperr)&&empty($vcperr)&&isset($_POST["cps"])){
//saving password in a session.
$_SESSION["pw"]=$_POST["vup"];
echo "<script>(confirm('Sure want to change password?')==1?alert('Password changed'):'');window.location='mmlh.php';</script>";}

echo '<center>
<fieldset><form method="post" action="" id="cpp" name="cpp"><h1><u><i>New Password</i></u></h1><br><small><u><b>Set new password</b></u></small><br><br><br>
<label>Password <input type="password" id="vup" name="vup" placeholder="Password"><span class="err"><br>'.$vperr.'</span></label><br><br>
<label>Confirm Password <input type="password" id="vucp" name="vucp" placeholder="Confirm Password"><span class="err"><br>'.$vcperr.'</span></label><br><br>
<small><b><p id="vp"></p></b></small><br>
<input type="button" name="pg" value="Generate Password" onclick="dsp();"><br><br><br><input type="submit" name="cps" value="Set Password"></form></fieldset></center>';
}

?>
</body></html>


