<?php
session_start();
if (isset($_SESSION["ceg"]) ? $_SESSION["ceg"] : 0) {
 echo '
    <style>
        table {
            width: 35%;
            margin: 20px auto;
            border-collapse: collapse;
            font-family: Arial, sans-serif;
            font-weight: bold;
            background-color: #f9f9f9;
        }
        th {
            background-color: red;
            color: white;
            font-size: 20px;
            padding: 10px;
        }
        td {
            padding: 10px;
            border: 1px solid #DDDDDD;
            vertical-align: top;
        }
        li {
            list-style: none;
            font-weight: 800;
        }
        img {
            max-width: 200px;
            height: auto;
            border: 1px solid #ccc;
            padding: 5px;
            background-color: #fff;
        }
              </style>';

 function display() {
        $rbdet = unserialize($_COOKIE["rbdet"]);
        echo "<table><tr><th colspan=2>Request</th></tr><ul>";
        echo "<tr><td><li>Issue </li></td><td>" . $rbdet["i"] . "</td></tr>";
        echo "<tr><td><li>Proof </li></td><td><img src='{$rbdet["file"][0]}'></td></tr>";
        echo "<tr><td><li>Letter </li></td><td><img src='{$rbdet["file"][1]}'></td></tr>";
        echo "<tr><td><li>Data and Time </li></td><td>" . $rbdet["dt"] . "</td></tr>";
        echo "<tr><td><li>Suggestion </li></td><td>" . $rbdet["sg"] . " </td></tr>";
        echo "</ul></table>";
        echo "<center><a href=\"mma.php\">Back</a><br>
        <br><button onclick=\"window.print()\">Print</button></center>";
    }

    display();
} else {
    echo '<center><h2><i>No request found..!</i></h2>
    <input type="button" onclick="window.location=\'mma.php'\" value="Click Me"><br><br>
    <a href="mmhh.php">Home</a><br><br>
    <input type="button" onclick="window.location=\'mma.php\'" value="Back"></center>';
}

?>