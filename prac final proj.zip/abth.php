<?php
session_start();
if (isset($_COOKIE["rct"]) ? $_COOKIE["rct"] : 0) {
    echo '
    <style>
        table {
            width: 50%;
            margin: 20px auto;
            border-collapse: collapse;
            font-family: Arial, sans-serif;
            font-weight: bold;
            background-color: #f9f9f9;
        }
        th {
            background-color: #4CAF50;
            color: white;
            font-size: 20px;
            padding: 10px;
        }
        td {
            padding: 10px;
            border: 1px solid #ddd;
            vertical-align: top;
        }
        li {
            list-style: none;
            font-weight: bold;
        }
        img {
            max-width: 200px;
            height: auto;
            border: 1px solid #ccc;
            padding: 5px;
            background-color: #fff;
        }
              </style>';
function display() {
$rdet = unserialize($_COOKIE["rdet"]);
echo "<br><table><tr><th colspan=2>Student Info</th></tr><ul>";
echo "<tr><td><li>Name </li></td><td>" . $rdet["n"] . "</td></tr>";
echo "<tr><td><li>Deptno </li></td><td>" . $rdet["dn"] . "</td></tr>";
echo "<tr><td><li>Phone no </li></td><td>" . $rdet["pn"] . "</td></tr>";
echo "<tr><td><li>Adhar no </li></td><td>" . $rdet["an"] . "</td></tr>";
echo "<tr><td><li>Address </li></td><td>" . $rdet["add"] . "</td></tr>";
echo "<tr><td><li>Mode of Transport </li></td><td>" . $rdet["mot"] . "</td></tr>";
echo "<tr><td><li>Distance </li></td><td>" . $rdet["d"] . " km</td></tr>";
echo "<tr><td><li>Shift </li></td><td>" . $rdet["sh"] . "</td></tr>";
echo "<tr><td><li>Status </li></td><td>" . $rdet["st"] . "</td></tr>";
echo "<tr><td><li>Reason </li></td><td>" . $rdet["r"] . "</td></tr>";
echo "<tr><td><li>Father Name </li></td><td>" . $rdet["fn"] . "</td></tr>";
echo "<tr><td><li>Father Income </li></td><td>" . $rdet["fi"] . "</td></tr>";
echo "<tr><td><li>Father Occupation </li></td><td>" . $rdet["fo"] . "</td></tr>";
echo "<tr><td><li>Mother Name </li></td><td>" . $rdet["mn"] . "</td></tr>";
echo "<tr><td><li>Mother Income </li></td><td>" . $rdet["mi"] . "</td></tr>";
echo "<tr><td><li>Mother Occupation </li></td><td>" . $rdet["mo"] . "</td></tr>";
echo "<tr><td><li>No of Siblings </li></td><td>" . $rdet["nos"] . "</td></tr>";
echo "<tr><td><li>Overall Income </li></td><td>" . $rdet["oi"] . "</td></tr>";
echo "<tr><td><li>Passport Photo </li></td><td><img src='{$rdet["file"]["pp"]}'></td></tr>";
echo "<tr><td><li>Ration card </li></td><td><img src='{$rdet["file"]["rc"]}'></td></tr>";
echo "<tr><td><li>Income certificate </li></td><td><img src='{$rdet["file"]["ic"]}'></td></tr>";
echo "<tr><td><li>Community certificate </li></td><td><img src='{$rdet["file"]["cc"]}'></td></tr>";
echo (isset($rdet["file"]["dc"])) ? "<tr><td><li>Death certificate </li></td><td><img src='{$rdet["file"]["dc"]}'></td></tr>" : "";
echo "<tr><td><li>Id card </li></td><td><img src='{$rdet["file"]["idc"]}'></td></tr>";
echo "<tr><td><li>Parent Approvel letter </li></td><td><img src='{$rdet["file"]["prl"]}'></td></tr>";
echo "<tr><td><li>Student Signature </li></td><td><img src='{$rdet["file"]["ss"]}'></td></tr>";
echo "<tr><td><li>Faculty letter </li></td><td><img src='{$rdet["file"]["fl"]}'></td></tr>";
echo "<tr><td><li>H.O.D Permit </li></td><td><img src='{$rdet["file"]["pl"]}'></td></tr>";
echo "</ul></table><br><hr>";
    }

    display();
} else {
echo '<center><h2><i>Oops...!<br>It seems like you aren\'t registered yet..!</i></h2>
<br><small><b><u><i>Click here to register</u></b></small><br>
<a href="pracmmh.php">Click Me</a><br><br>
<input type="button" onclick="window.location=\'pracmmh.php\'" value="Click Me"><br><br>
<h2>Note: Kindly register to update your details.</h2><br>
<a href="mmhh.php">Home</a><br><br>
<input type="button" onclick="window.location=\'mmhh.php\'" value="Back"></center>';
}

?>
