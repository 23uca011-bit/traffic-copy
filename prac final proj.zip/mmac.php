<?php
session_start();
?>
<html>
<head>
<style>
table {border-collapse: collapse;}
th, td {padding: 10px;}
</style>
<script>
function dis(){
let v=document.getElementById('t');
v.innerHTML=`<tr>
<th><?php 
if(isset($_SESSION["dn"]))
echo substr($_SESSION["dn"],0,7)."***";?>
<td id="cb"><input type="button" value="Take Action"></td>
</tr>`;}
</script>
<style>
</style>
</head>
<body>
<fieldset>
<center>
<i><u><small><b>REQUEST</b></i></u></small><br><hr>
<h1><u>Status</u></h1><br>
<input type="button" name="sm" id="sm" value="show list" onclick="dis()"><br><br><br>
<table border="2px" id="t">
<!--
<tr>
<th><?php echo (isset($_SESSION["dn"])?substr($_SESSION["rct"],0,6):"")."***";?></th></tr>
<tr>
<td id="cb"><input type="button" value="Take Action"></td>
</tr>
-->
</table>
</center>
</fieldset>
</body>
</html>





