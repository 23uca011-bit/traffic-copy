<?php
session_start();
?>
<html>
<head>
<style>
table {border-collapse: collapse;}
th, td {padding: 10px;}
</style>
<script>
function dis(){
let v=document.getElementById('t');
v.innerHTML=`<tr>
<th>No.of.students registered</th></tr>
<tr>
<td><?php echo (isset($_COOKIE["rct"])?$_COOKIE["rct"]:"");?></td>
</tr>`;}
</script>
<style>
</style>
</head>
<body>
<fieldset>
<center>
<i><u><h1>Hi<?php echo " , Welcome Admin <br>".(isset($_SESSION["n"])?$_SESSION["n"]:"");?></i></u></h1><br><hr>
<h1><u>Status</u></h1><br>
<input type="button" name="sm" id="sm" value="Show Status" onclick="dis()"><br><br><br>
<table border="2px" id="t">
<!--
<tr>
<th>No.of.students registered</th></tr>
<tr>
<td><?php echo (isset($_COOKIE["rct"])?$_COOKIE["rct"]:"");?></td>
</tr>
-->
</table>
</center>
</fieldset>
</body>
</html>





