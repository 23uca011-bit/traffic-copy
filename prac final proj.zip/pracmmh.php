<?php
//start session
session_start();

if(!(isset($_COOKIE["rct"])?1:0)){
$rdet=[[]];$farr=""; //array variable to store details.
$nerr=$dnerr=$cnerr=$aderr=$mterr=$derr=$serr=$sterr=$rerr=$ferr=$merr=$sberr=$foerr=$moerr=$acnerr=$oerr=""; //num&alph input
$rcerr=$icerr=$ccerr=$idcerr=$pperr=$flerr=$plerr=$sserr=$prlerr=$fuerr=""; //files input

//validating function val
function val(){
global $nerr,$dnerr,$cnerr,$aderr,$mterr,$derr,$serr,$sterr,$rerr,$ferr,$merr,$sberr,$oerr,$foerr,$moerr,$acnerr,$rcerr,$icerr,$ccerr,$idcerr,$pperr,$flerr,$plerr,$sserr,$prlerr; //files input
//num&alph validation
//Name
if(empty($_POST["un"]))
$nerr="Name can't be empty.";
else if(strlen($_POST["un"])>30)
$nerr="Name can't be too big.";
//Deptno
if(empty($_POST["udn"]))
$dnerr="Department no cannot be empty";
else if(!(preg_match('/^\d{2}-[a-zA-Z]{3}-\d{3}$/',$_POST["udn"]))) 
$dnerr="Department no incorrect format";
//Contactno
if(empty($_POST["up"]))
$cnerr="Contact no cannot be empty";
else if(strlen($_POST["up"])!=10) 
$cnerr="Contact no must be 10 nos";
//Adharno
if(empty($_POST["uacn"]))
$acnerr="Adhar no cannot be empty";
else if(strlen($_POST["uacn"])!=12) 
$acnerr="Adhar no must be 12 nos";
//Address
if(empty($_POST["uadd"]))
$aderr="Address cannot be empty";
else if(strlen($_POST["uadd"])>150) 
$aderr="Address must be less than 150 chars";
else if(strlen($_POST["uadd"])<10) 
$aderr="Address is too short,Please provide a vaild address";
//Mode of Transport
if(!isset($_POST["umot"])||empty($_POST["umot"]))
$mterr="Please select Mode of Transport";
//Distance
if(empty($_POST["ud"]))
$derr="Distance cannot be empty";
else if($_POST["ud"]<0||strlen($_POST["ud"])>2) 
$derr="invalid Distance";
//Shift
if(!isset($_POST["ush"])||empty($_POST["ush"]))
$serr="Please select Shift";
//Status
if(!isset($_POST["us"])||empty($_POST["us"]))
$sterr="Please select Status";
//Reason
if(empty($_POST["ur"]))
$rerr="Reason cannot be empty";
else if(strlen($_POST["ur"])>150) 
$rerr="Reason must be less than 150 chars";
else if(strlen($_POST["ur"])<10) 
$rerr="Reason is too short,Please provide a vaild reason";
//Father Details
if(empty($_POST["ufn"])&&empty($_POST["ufi"])&&empty($_POST["ufo"]))
$ferr="Father Name,Income,Occupation cannot be empty";
else if(empty($_POST["ufn"])||empty($_POST["ufi"])&&$_POST["umi"]!=0)
$ferr="Please fill both fields";
else if(strlen($_POST["ufi"])>10) 
$ferr="Income is too large";
else if($_POST["ufi"]<0) 
$merr="Income can't be a negative value";
//Mother Details
if(empty($_POST["umn"])&&empty($_POST["umi"])&&empty($_POST["umo"]))
$merr="Mother Name,Income,Occupation cannot be empty";
else if(empty($_POST["umn"])||empty($_POST["umi"])&&$_POST["umi"]!=0)
$merr="Please fill both fields";
else if(strlen($_POST["umi"])>10) 
$merr="Income is too large";
else if($_POST["umi"]<0) 
$merr="Income cannot be a negative value";
//Sibling Details
if(empty($_POST["uns"]))
$sberr="No.of.Siblings cannot be empty";
else if($_POST["uns"]>15) 
$sberr="Too large value";
else if($_POST["uns"]<0) 
$merr="No.of.Siblings cannot be a negative value";
//files validation
//Ration card
if(empty($_FILES["urf"]["name"]))
$rcerr="Please upload Ration card";
//Income certificate
if(empty($_FILES["uif"]["name"]))
$icerr="Please upload Income certificate";
//Community certificate
if(empty($_FILES["ucf"]["name"]))
$ccerr="Please upload Community certificate";
//Id card
if(empty($_FILES["uidf"]["name"]))
$idcerr="Please upload Id card";
//Passort Photo
if(empty($_FILES["upf"]["name"]))
$pperr="Please upload Passort Photo";
//Parent Letter
if(empty($_FILES["uprl"]["name"]))
$prlerr="Please upload Parent Letter";
//Student Sign Letter
if(empty($_FILES["uss"]["name"]))
$sserr="Please upload Student Signature";
//Faculty Letter
if(empty($_FILES["ufl"]["name"]))
$flerr="Please upload Faculty Letter";
//H.O.D Permit Letter
if(empty($_FILES["upl"]["name"]))
$plerr="Please upload H.O.D Permit Letter";}


//pracmmp.php
function ful($fn){
if (($_SERVER['REQUEST_METHOD'] == 'POST')&&($_FILES[$fn]["error"]==UPLOAD_ERR_OK)){
global $rdet,$oerr;
$td = "uploads/";
if (!file_exists($td)) 
mkdir($td, 0777, true);
$f = $_FILES[$fn];
$tf = $td . basename($f["name"]);
$ft = strtolower(pathinfo($tf, PATHINFO_EXTENSION));
$at = ['jpg', 'jpeg', 'png', 'gif'];
if (!in_array($ft, $at)) {
echo "Only JPG, JPEG, PNG & GIF files are allowed.";
exit;}
if(!move_uploaded_file($f["tmp_name"], $tf))
$oerr="Can't upload file. Error occured..rectify to proceed further";
return $tf;
}}


if(isset($_POST["urb"])){
//validating(TEXT/NUMBER)inputs by calling val.
val();

//checking error free
if(empty($nerr)&&empty($dnerr)&&empty($cnerr)&&empty($aderr)&&empty($mterr)&&empty($derr)&&empty($snerr)&&empty($stnerr)&&empty($rerr)&&empty($ferr)&&empty($merr)&&empty($sberr)&&empty($rcerr)&&empty($icerr)&&empty($ccerr)&&empty($idcerr)&&empty($pperr)&&empty($prlerr)&&empty($sserr)&&empty($flerr)&&empty($plerr)&&empty($oerr)){

//storing input values in a array.
$rdet=array(
"n"=>$_POST["un"],
"dn"=>$_POST["udn"],
"pn"=>$_POST["up"],
"an"=>$_POST["uacn"],
"add"=>$_POST["uadd"],
"mot"=>$_POST["umot"],
"d"=>$_POST["ud"],
"sh"=>$_POST["ush"],
"st"=>(isset($_POST["us"]) ? $_POST["us"] : ""),
"r"=>$_POST["ur"],
"fn"=>$_POST["ufn"],
"fi"=>$_POST["ufi"],
"fo"=>$_POST["ufo"],
"mn"=>$_POST["umn"],
"mi"=>$_POST["umi"],
"mo"=>$_POST["umo"],
"nos"=>$_POST["uns"],
"apst"=>"",
"oi"=>((int)$_POST["ufi"] + (int)$_POST["umi"]),
"td"=>"uploads/"

);

//storing files in a array.
$farr=array("pp"=>"upf","rc"=>"urf","ic"=>"uif","cc"=>"ucf","dc"=>"udf","idc"=>"uidf","prl"=>"uprl","ss"=>"uss","fl"=>"ufl","pl"=>"upl");

//validating 
foreach($farr as $key=>$value)
$rdet["file"][$key]=ful($value); 

//uploading files.
//foreach($farr as $key=>$value)
//$rdet["file"][$key]=$value; // $rdet["file"]=$value; or $rdet["file"][$key]=$value;

if(empty($oerr)){
//finally storing inputs in cookie(serializing)
setcookie("rdet",serialize($rdet),time()+86400*30);

//unserializing
$rdet = unserialize($_COOKIE["rdet"]);

//DB CONNECTION AND INSERTING VALUES
$con=new mysqli("localhost","root","","loyola");
$con->query("insert into loyolite (Name,Dept_no,Contact_no,Adhar_no,Address,Mode_of_transport,Distance,Shift,Status,Reason,Father_name,Father_income,Father_occupation,Mother_name,Mother_income,Mother_occupation,No_of_sibling,Overall_income,Passport_photo,Ration_card,Income_certificate,Community_certificate,Death_certificate,Id_card,Parent_letter,Student_sign,Faculty_letter,HOD_permit,Approvel_status)values('{$rdet["n"]}','{$rdet["dn"]}','{$rdet["pn"]}','{$rdet["an"]}','{$rdet["add"]}','{$rdet["mot"]}','{$rdet["d"]}','{$rdet["sh"]}','{$rdet["st"]}','{$rdet["r"]}','{$rdet["fn"]}','{$rdet["fi"]}','{$rdet["fo"]}','{$rdet["mn"]}','{$rdet["mi"]}','{$rdet["mo"]}','{$rdet["nos"]}','{$rdet["oi"]}','{$rdet["file"]["pp"]}','{$rdet["file"]["rc"]}','{$rdet["file"]["ic"]}','{$rdet["file"]["cc"]}','{$rdet["file"]["dc"]}','{$rdet["file"]["idc"]}','{$rdet["file"]["prl"]}','{$rdet["file"]["ss"]}','{$rdet["file"]["fl"]}','{$rdet["file"]["pl"]}','{$rdet["apst"]}')");


//alert confirmation.
echo "<script>alert('SUCCESSFULLY REGISTERED.');window.location='mmhh.php';</script>";

//finding successfully registered count.
if(isset($_COOKIE["rct"]))
setcookie("rct",$_COOKIE["rct"]+1,time()+86400*30);
else
setcookie("rct",1,time()+86400*30);
$r=(empty($rdet["file"]["dc"])?"nill":$rdet["file"]["dc"]);
}}
else
$oerr="Error occured....<br>Please rectify to proceed further.";
}

//html
echo '
<style>
h3,h5{text-align: center;} 
.err{color:red;} 
</style>
<center>
<h1><b><u>M M REGISTERY</u></b></h1><br>
</center>
    <form method="post" action="" id="mmf" enctype="multipart/form-data">
    <fieldset id="fmregister">
    <b>
    <center><h2><u>Applicant Details</u></h2></center>
    <div id="sd">
    <h5><u>Student Details</u></h5><center><span class="err"><small><i>'.$oerr.'</i></small></span></center><br><br>
    <label>Name: <input type="text" id="un" name="un" placeholder="Name" maxlength="25" ><span class="err"> * <br> '. $nerr .'</span></label><br><br>
    <label>Department no: <input type="text" id="udn" name="udn" placeholder="23-UCA-024" maxlength="10" ><span class="err"> * <br> '. $dnerr .'</span></label><br><br>
    <label>Phone no: <input type="number" id="up" name="up" placeholder="Contact no" ><span class="err"> * <br>'.$cnerr.'</span></label><br><br>
    <label>Adhar card no: <input type="text" id="uacn" name="uacn" placeholder="123456789000" maxlength="12" ><span class="err"> * <br> '. $acnerr .'</span></label><br><br>
    <label>Address: <textarea id="uadd" name="uadd" maxlength="150" ></textarea><span class="err"> * <br>'.$aderr.'</span></label><br><br>
    <label>Mode of Transport: <select id="umot" name="umot" >
    <option value=""></option>
    <option value="Train">Train</option>
    <option value="Bus">Bus</option>
    <option value="Car">Car</option>
    <option value="Bike">Bike</option>
    <option value="Bicycle">Bicycle</option>
    <option value="Walk">Walk</option>
    <option value="Bus&Train">Bus&Train</option>
    </select></label><span class="err"> * <br>'.$mterr.'</span><br><br>
    <label>Distance: <input type="number" id="ud" name="ud" placeholder="in km" ><span class="err"> * <br>'.$derr.'</span></label><br><br>
    Shift: <select id="ush" name="ush" >
    <option value=""></option>
    <option value="I-(F/N)">I</option>
    <option value="II-(A/N)">II</option>
    </select><span class="err"> * <br>'.$serr.'</span><br><br>
    <label>Status: </label>
    <label><input type="radio" id="us" name="us" value="Orphan">Orphen </label>
    <label><input type="radio" id="us" name="us" value="Semi-Orphen">Semi-Orphen </label>
    <label><input type="radio" id="us" name="us" value="None" >None </label><span class="err"> * <br>'.$sterr.'</span><br><br>
    <label>Reason: <textarea id="ur" name="ur" maxlength="150" ></textarea><span class="err"> * <br>'.$rerr.'</span></label><br><br>
    <hr></div>
    <div id="fd">
    <h5><u>Family Details</u></h5>
    <label>Father: <input type="text" id="ufn" name="ufn" placeholder="Name" maxlength="25" ><input type="number" id="ufi" name="ufi" placeholder="Income" ><input type="text" id="ufo" name="ufo" placeholder="Occupation" maxlength="25" ><span class="err"> * <br>'.$ferr.'</span></label><br><br>
    <label>Mother: <input type="text" id="umn" name="umn" placeholder="Name" maxlength="25" ><input type="number" id="umi" name="umi" placeholder="Income" ><input type="text" id="umo" name="umo" placeholder="Occupation" maxlength="25" ><span class="err"> * <br>'.$merr.'</span></label><br><br>
    <label>Siblings: <input type="number" id="uns" name="uns" placeholder="No.of.siblings" ><span class="err"> * <br>'.$sberr.'</span></label><br><br>
    Overall Income: <p id="oi"></p><hr></div>
    <div id="dd">
    <h5><u>Documents</u></h5>
    <label>Ration card: <input type="file" id="urf" name="urf" ><span class="err"> * <br>'.$rcerr.'</span></label><br><br>
    <label>Income certificate: <input type="file" id="uif" name="uif" ><span class="err"> * <br>'.$icerr.'</span></label><br><br>
    <label>Community certificate: <input type="file" id="ucf" name="ucf" ><span class="err"> * <br>'.$ccerr.'</span></label><br><br>
    <label>Death certificate(if applicable): <input type="file" id="udf" name="udf" ></label><br><br><br>
    <label>Id card: <input type="file" id="uidf" name="uidf" ><span class="err"> * <br>'.$idcerr.'</span></label><br><br>
    <label>Passport photo: <input type="file" id="upf" name="upf" ><span class="err"> * <br>'.$pperr.'</span></label><br><br>
    <hr></div>
    <div id="pa"> 
    <h5><u>Parent Approvel</u></h5>
    <label>Parent Request Letter(with sign): <input type="file" id="uprl" name="uprl" ><span class="err"> * <br>'.$prlerr.'</span></label>
    <br><br><hr></div>
    <div id="ss"> 
    <h5><u>Student Signature</u></h5>
    <label>Student Sign: <input type="file" id="uss" name="uss" ><span class="err"> * <br>'.$sserr.'</span></label>
    <br><br><hr></div>
    <div id="fr"> 
    <h5><u>Faculty Recommendation</u></h5>
    <label>Recommend Letter: <input type="file" id="ufl" name="ufl" ><span class="err"> * <br>'.$flerr.'</span></label>
    <br><br><hr></div>
    <div id="hp"> 
    <h5><u>H.O.D Recommendation</u></h5>
    <label>Permit Letter: <input type="file" id="upl" name="upl" ><span class="err"> * <br>'.$plerr.'</span></label>
    </div><br><br>
<hr><center>
<small><b><u>choose action</u></b></small><br><br>
<input type="submit" name="urb" id="urb" value="Register"><br><br>
<span class="err">'.$oerr.'</span><br><br>
<a href="mmhh.php">Home</a></center>
</b>
</fieldset>
</form>
';}
else
echo "<center><h1>Already Registered...</h2><br><br>Click here to return<br><a href=\"mmhh.php\">Home</a></center>";
?>

