<?php
session_start();
if (isset($_COOKIE["rct"]) ? $_COOKIE["rct"] : 0) {
echo '
<style>
table {
width: 50%;
margin: 20px auto;
border-collapse: collapse;
font-family: Arial, sans-serif;
font-weight: bold;
background-color: #f9f9f9;
}
th {
background-color: #4CAF50;
color: white;
font-size: 20px;
padding: 10px;
}
td {
padding: 10px;
border: 1px solid #ddd;
vertical-align: top;
text-align:center;
}
li {
list-style: none;
font-weight: 800;
}
img {
max-width: 200px;
height: auto;
border: 1px solid #ccc;
padding: 5px;
background-color: #fff;
}
.message-box button {
      margin-top: 15px;
      padding: 10px 20px;
      background-color: lime;
      border: 2px solid black;
      color: white;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      font-weight:bold;
    }

#r {background-color: red;}
#a {color: green;}
#ua {color: red;}

</style>';
function display($rdet) {
//$rdet = unserialize($_COOKIE["rdet"]);
//if(empty($rdet["Approvel status"])){
global $con;
echo "<form method='post'><br><table id='tbb'><tr><th colspan=2>Student Info</th></tr><ul>";
echo "<tr><td><li>Deptno </li></td><td>" . $rdet["Deptno"] . "</td></tr>";
echo "<tr><td><li>Phone no </li></td><td>" . $rdet["Contact no"] . "</td></tr>";
echo "<tr><td><li>Address </li></td><td>" . $rdet["Address"] . "</td></tr>";
echo "<tr><td><li>Mode of Transport </li></td><td>" . $rdet["Mode of transport"] . "</td></tr>";
echo "<tr><td><li>Distance </li></td><td>" . $rdet["Distance"] . " km</td></tr>";
echo "<tr><td><li>Shift </li></td><td>" . $rdet["Shift"] . "</td></tr>";
echo "<tr><td><li>Status </li></td><td>" . $rdet["Status"] . "</td></tr>";
echo "<tr><td><li>Reason </li></td><td>" . $rdet["Reason"] . "</td></tr>";
echo "<tr><td><li>Father Name </li></td><td>" . $rdet["Father name"] . "</td></tr>";
echo "<tr><td><li>Father Income </li></td><td>" . $rdet["Father income"] . "</td></tr>";
echo "<tr><td><li>Mother Name </li></td><td>" . $rdet["Mother name"] . "</td></tr>";
echo "<tr><td><li>Mother Income </li></td><td>" . $rdet["Mother income"] . "</td></tr>";
echo "<tr><td><li>No of Siblings </li></td><td>" . $rdet["No of sibling"] . "</td></tr>";
echo "<tr><td><li>Overall Income </li></td><td>" . $rdet["Overall income"] . "</td></tr>";
echo "<tr><td><li>Passport Photo </li></td><td><img src='{$rdet["Passport photo"]}'></td></tr>";
echo "<tr><td><li>Ration card </li></td><td><img src='{$rdet["Ration card"]}'></td></tr>";
echo "<tr><td><li>Income certificate </li></td><td><img src='{$rdet["Income certificate"]}'></td></tr>";
echo "<tr><td><li>Community certificate </li></td><td><img src='{$rdet["Community certificate"]}'></td></tr>";
echo (isset($rdet["file"]["dc"])) ? "<tr><td><li>Death certificate </li></td><td><img src='{$rdet["Death certificate"]}'></td></tr>" : "";
echo "<tr><td><li>Id card </li></td><td><img src='{$rdet["Id card"]}'></td></tr>";
echo "<tr><td><li>Faculty letter </li></td><td><img src='{$rdet["Faculty letter"]}'></td></tr>";
echo "<tr><td><li>H.O.D Permit </li></td><td><img src='{$rdet["HOD permit"]}'></td></tr>";
if(empty($rdet['Approvel status']))
echo '<tr id="tb"><td colspan=2><center><input type="submit" value="Take action" name="apb"></center></td></tr>';
else
echo "<tr><td><center><i><b>Approvel status</b></i></td><td><i id='ca'><b>".$rdet["Approvel status"]."</b></i></center></td></tr>";
echo "</ul></table></form><br><hr>";
//APPROVEL
if(isset($_POST["apb"])&&empty($rdet['Approvel status'])){
echo '
<script>
document.getElementById("tb").innerHTML=`<td>
<p><b><i>Do you want to approve?</i></b></p></td><td>
<div class="message-box">
<form method="post">
<button type="submit" name="r" id="r"><i>Reject</button>
<button type="submit" name="a">Approve</i></button>
</form></div></td>`</script>';}
$ast="";
if(isset($_POST["a"])&&empty($rdet['Approvel status'])){
echo "<script>
if(confirm('Sure,want to approve?'))
alert('approved');
document.getElementById('ca').style.color='lime';
</script>";
$ast="Approved";}
else if(isset($_POST["r"])&&empty($rdet['Approvel status'])){
echo "<script>
if(confirm('Sure,want to unapprove?'))
alert('unapproved');
document.getElementById('ca').style.color='red';
</script>";
$ast="Unapproved";}
if(!empty($ast)){
$con->query("UPDATE loyolite SET `Approvel status`='{$ast}' WHERE Deptno='{$rdet["Deptno"]}'");
//setcookie("rdet",serialize($rdet),time()+86400*30);
echo "<script>document.getElementById('tb').innerHTML=`<td><center><i><b>Approvel status</b></i></td><td><i id='ca'><b>{$rdet['Approvel status']}</b></i></center></td></tr>`;</script>";}

}
//Fetching from DB
$con=new mysqli("localhost","root","","loyola");
$res=$con->query("select * from loyolite");
foreach($res as $rdet)
display($rdet);
print_r($res);
echo "<center><a href=\"mma.php\">Back</a><br>
<br><button onclick=\"window.print()\">Print</button></center>";
} 
else 
echo "<center><h2><i>Oops...!<br>It seems like No one registered yet..!</i></h2><br><a href='mma.php'>Home</a></center><br><br>";
?>
