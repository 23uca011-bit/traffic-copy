<?php
session_start();
$_SESSION["ceg"]=0;
?>

<?php
$err="";
if(isset($_POST["s"])){
//validation
if(empty($_POST["i"])||empty($_POST["dt"])||empty($_POST["sg"]))
$err="<small><b><i>Please fill out all</i></b></small><br>";
else if(empty($_FILES["pf"]["name"])||empty($_FILES["l"]["name"]))
$err="<small><b><i>Please upload files</i></b></small><br>";
else{
$rbdet=array(
"i"=>$_POST["i"],
"dt"=>$_POST["dt"],
"sg"=>$_POST["sg"],
"file"=>["uploads\\".basename($_FILES["pf"]["name"]),"uploads\\".basename($_FILES["l"]["name"])]);
if(empty($err)){
move_uploaded_file($_FILES["pf"]["tmp_name"],"uploads\\".basename($_FILES["pf"]["name"]));
move_uploaded_file($_FILES["l"]["tmp_name"],"uploads\\".basename($_FILES["l"]["name"]));
setcookie("rbdet",serialize($rbdet),time()+86400*30);
$_SESSION["ceg"]=1;
echo "<script>alert('REQUEST RAISED SUCCESSFULLY')</script>";}}
}
//HTML
echo '<style>
table {border-collapse: collapse;}
th, td {padding: 10px;}
</style>
<script>
</script>
</head>
<fieldset>
<center>
<form method="post" enctype="multipart/form-data">
<h2><i><u>REQUEST</b></i></u></h2><hr>
<h1><u>Raise Request</u></h1><br>
<u><i><h2 id="h"></h2></i></u>
<table border="2px" id="t">
<tr>
<td colspan=2><center><small><b><u>Request Box</u></center></b></small></td></tr><tr>
<td>Issue</td><td><input type="textarea" Placeholder="Type issue" name="i" id="i"></td></tr>
<tr><td>Proof</td><td><input type="file" name="pf" id="pf"></td></tr>
<tr><td>Letter</td><td><input type="file" name="l" id="l"></td></tr>
<tr><td>Date&Time</td><td><input type="datetime-local" name="dt" id="dt"></td></tr>
<tr><td>Suggest</td><td><input type="textarea" Placeholder="Your Suggestion" name="sg" id="sg"></td></tr>
<tr><td>Action</td><td><input type="submit" name="s" id="s"></td></tr>
</table>'.(isset($err)?$err:"").'
</form></center>
</fieldset>';
?>











