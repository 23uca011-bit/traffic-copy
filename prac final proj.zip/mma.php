<?php
session_start();
?>
<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;}
li {
  float: left;}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;}

li a:hover {
  background-color: lime;}
</style>
</head>
<body>
<fieldset>
<center>
<i><u><h1>Hi<?php echo " , Welcome Admin <br>".(isset($_SESSION["n"])?$_SESSION["n"]:"");?></i></u></h1>
<br><br>
<ul>
  <li><a class="active" href="#home" onclick="return false;">Home</a></li>
  <li><a href="mmar.php">Registered</a></li>
  <li><a href="mmas.php" >Status</a></li>
  <li><a href="mmta.php">Take action</a></li>
  <li><a href="abth.php">About</a></li>
  <li>
  <a href="#" 
     onclick="if (confirm('Sure, do you want to logout?')) window.location='mmlop.php';return false;">
    Logout
  </a>
</li>
</ul>
</center>
</fieldset>
</body>
</html>