<?php

//storing roles 
session_start();
if(isset($_POST["u"]))
$_SESSION["rol"]="u";
if(isset($_POST["lh"]))
$_SESSION["rol"]="lh";
if(isset($_POST["a"]))
$_SESSION["rol"]="a";

//identifying roles and redirecting 
if(isset($_POST["u"])||isset($_POST["lh"])||isset($_POST["a"]))
echo "<script>window.location='mmlh.php'</script>";
?>


<html>
<head><title>LOGIN ROLES</title>
<script>
</script>
</head>
<body>
<fieldset><center>
<form method="post">
<h1><u>LOGIN</u></h1>
<input type="submit" id="u" name="u" value="User">
<input type="submit" id="lh" name="lh" value="Local Host">
<input type="submit" id="a" name="a" value="Admin">
</form></center>
</fieldset>
</body> 
</html>