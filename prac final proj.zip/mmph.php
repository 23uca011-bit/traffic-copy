<?php
session_start();
if (isset($_COOKIE["rct"]) ? $_COOKIE["rct"] : 0) {
//UNSERIALIZE COOKIE(REGISTER)
$rdet=unserialize($_COOKIE["rdet"]);
//UNSERIALIZE COOKIE(SIGUP)
$sudet=unserialize($_COOKIE["sudet"]);


$dn=$rdet["dn"];
$gl=(substr($dn,3,1)=="U"?"UG":"PG");
switch(substr($dn,3,1)=="P"?("U".substr($dn,4,2)):substr($dn,3,3)){
case "UCA": 
$dpt="Computer Science";$cs="Bca";break;
case "UCS": 
$dpt="Computer Science";$cs="B.Sc Cs";break;
case "UCH": 
$dpt="Chemistry";$cs="B.Sc Chemistry";break;
case "UPH": 
$dpt="Physics";$cs="B.Sc Physics";break;
case "UFR": 
$dpt="French";$cs="BA.French";break;
case "UHT": 
$dpt="History";$cs="BA.History";break;
case "UST": 
$dpt="Statistics";$cs="BA.Statistics";break;
}
//SERIALIZE COOKIE(PROFILE)
$pdet=array(
"n"=>$sudet["sn"],
"dpt"=>$dpt,
"gl"=>(substr($dn,3,1)=="U"?"UG":"PG"),
"y"=>((substr(date("Y"),-2)-substr($dn,0,2))+1),
"rn"=>(int)substr($dn,7),
"b"=>(substr(date("Y"),0,2).substr($dn,0,2))."-".($gl=="UG"?(substr($dn,0,2)+3):(substr($dn,0,2)+2)),
"cs"=>($gl=="PG"?("M".substr($cs,1)):$cs)
);
setcookie("pdet",serialize($pdet),time()+3600*24);

//Display details
echo "<fieldset><center><h1><u><i>Profile</i></u></h1><ul></center><u><i><small>student info</small></i></u><br><br>";
echo "<li> Name: ".strtoupper($pdet["n"])."</li><br>";
echo "<li> Department no: ".$rdet["dn"]."</li><br>";
echo "<li> Graduatation Level: ".$pdet["gl"]."</li><br>";
echo "<li> Department: ".$pdet["dpt"]."</li><br>";
echo "<li> Course: ".$pdet["cs"]."</li><br>";
echo "<li> Year: ".$pdet["y"]."</li><br>";
echo "<li> Roll-no: ".$pdet["rn"]."</li><br>";
echo "<li> Batch: ".$pdet["b"]."</li><br>";
//echo "<li> Batch: ".(substr(date("Y"),0,2).substr($dn,0,2))."-".(substr(date("Y"),0,2)).(substr($dn,0,2)+3)."</li><br>";
echo "<li> Shift: ".$rdet["sh"]."</li><br>";
echo "<li> Status: "."Active <input type=radio checked>"."</li><br>";
echo "</ul><br><br><center><button onclick=\"window.location='mmhh.php'\";>Back</center>";
}
else{
echo '<center><h2><i>Oops...!<br>It seems like you aren\'t registered yet..!</h2><br><small><b><u><i>Click here to register</u></b></small><br>
<a href="pracmmh.php">Click Me</a><br><br><input type="button" onclick="window.location=\'pracmmh.php\'"; value="Click Me"></i><br><br><h2>Note:Kindly register to update your profile.</h2><br><a href="mmhh.php">Home</a><br><br><input type="button" onclick="window.location=\'mmhh.php\'"; value="Back">
</center>';
}

?>
