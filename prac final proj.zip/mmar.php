<?php
session_start();
if (isset($_COOKIE["rct"]) ? $_COOKIE["rct"] : 0) {

//Interface design
echo '
<style>
table {
width: 50%;
margin: 20px auto;
border-collapse: collapse;
font-family: Arial, sans-serif;
font-weight: bold;
background-color: #f9f9f9;
}
th {
background-color: #4CAF50;
color: white;
font-size: 20px;
padding: 10px;
}
td {
padding: 10px;
border: 1px solid #ddd;
vertical-align: top;
text-align:center;
}
li {
list-style: none;
font-weight: 800;
}
img {
max-width: 200px;
height: auto;
border: 1px solid #ccc;
padding: 5px;
background-color: #fff;
}
.message-box button {
      margin-top: 15px;
      padding: 10px 20px;
      background-color: lime;
      border: 2px solid black;
      color: white;
      border-radius: 8px;
      cursor: pointer;
      font-size: 16px;
      font-weight:bold;
    }

#r {background-color: red;}
#a {color: green;}
#ua {color: red;}

</style>';




//Function to display records.
function display($rdet) {
//Db connection variable.
global $con;
//Displays record 
echo "<form method='post'><br><table id='tbb'><tr><th colspan=2>Student Info</th></tr><ul>";
echo "<tr><td><li>Name </li></td><td>" . $rdet["Name"] . "</td></tr>";
echo "<tr><td><li>Deptno </li></td><td>" . $rdet["Dept_no"] . "</td></tr>";
echo "<tr><td><li>Phone no </li></td><td>" . $rdet["Contact_no"] . "</td></tr>";
echo "<tr><td><li>Adhar no </li></td><td>" . $rdet["Adhar_no"] . "</td></tr>";
echo "<tr><td><li>Address </li></td><td>" . $rdet["Address"] . "</td></tr>";
echo "<tr><td><li>Mode of Transport </li></td><td>" . $rdet["Mode_of_transport"] . "</td></tr>";
echo "<tr><td><li>Distance </li></td><td>" . $rdet["Distance"] . " km</td></tr>";
echo "<tr><td><li>Shift </li></td><td>" . $rdet["Shift"] . "</td></tr>";
echo "<tr><td><li>Status </li></td><td>" . $rdet["Status"] . "</td></tr>";
echo "<tr><td><li>Reason </li></td><td>" . $rdet["Reason"] . "</td></tr>";
echo "<tr><td><li>Father Name </li></td><td>" . $rdet["Father_name"] . "</td></tr>";
echo "<tr><td><li>Father Income </li></td><td>" . $rdet["Father_income"] . "</td></tr>";
echo "<tr><td><li>Father Occupation </li></td><td>" . $rdet["Father_occupation"] . "</td></tr>";
echo "<tr><td><li>Mother Name </li></td><td>" . $rdet["Mother_name"] . "</td></tr>";
echo "<tr><td><li>Mother Income </li></td><td>" . $rdet["Mother_income"] . "</td></tr>";
echo "<tr><td><li>Mother Occupation </li></td><td>" . $rdet["Mother_occupation"] . "</td></tr>";
echo "<tr><td><li>No of Siblings </li></td><td>" . $rdet["No_of_sibling"] . "</td></tr>";
echo "<tr><td><li>Overall Income </li></td><td>" . $rdet["Overall_income"] . "</td></tr>";
echo "<tr><td><li>Passport Photo </li></td><td><img src='{$rdet["Passport_photo"]}'></td></tr>";
echo "<tr><td><li>Ration card </li></td><td><img src='{$rdet["Ration_card"]}'></td></tr>";
echo "<tr><td><li>Income certificate </li></td><td><img src='{$rdet["Income_certificate"]}'></td></tr>";
echo "<tr><td><li>Community certificate </li></td><td><img src='{$rdet["Community_certificate"]}'></td></tr>";
echo (isset($rdet["file"]["dc"])) ? "<tr><td><li>Death certificate </li></td><td><img src='{$rdet["Death_certificate"]}'></td></tr>" : "";
echo "<tr><td><li>Id card </li></td><td><img src='{$rdet["Id_card"]}'></td></tr>";
echo "<tr><td><li>Parent Approvel letter </li></td><td><img src='{$rdet["Parent_letter"]}'></td></tr>";
echo "<tr><td><li>Student Signature </li></td><td><img src='{$rdet["Student_sign"]}'></td></tr>";
echo "<tr><td><li>Faculty letter </li></td><td><img src='{$rdet["Faculty_letter"]}'></td></tr>";
echo "<tr><td><li>H.O.D Permit </li></td><td><img src='{$rdet["HOD_permit"]}'></td></tr>";


//Checking approvel status.
if(empty($rdet['Approvel status']))
echo '<tr id="tb"><td colspan=2><center><input type="submit" value="Take action" name="apb"></center></td></tr>';
else
echo "<tr><td><center><i><b>Approvel status</b></i></td><td><i id='ca'><b>".$rdet["Approvel status"]."</b></i></center></td></tr>";
echo "</ul></table></form><br><hr>";  //record displaying table closes here.



if(isset($_POST["apb"])){
$con->query("UPDATE loyolite SET `Approvel_status`= \"clicked\" WHERE Dept_no='{$rdet["Dept_no"]}'");

}

//APPROVEL
if(isset($_POST["apb"])&&($rdet['Approvel_status'])=="clicked"){
echo '
<script>
document.getElementById("tb").innerHTML=`<td>
<p><b><i>Do you want to approve?</i></b></p></td><td>
<div class="message-box">
<form method="post">
<button type="submit" name="r" id="r"><i>Reject</button>
<button type="submit" name="a">Approve</i></button>
<input type="hidden" name="deptno" value=\'{$rdet["Dept_no"]}\'>
</form></div></td>`</script>';}


$ast="";
if(isset($_POST["a"])&&empty($rdet['Approvel status'])){
echo "<script>
if(confirm('Sure,want to approve?'))
alert('approved');
document.getElementById('ca').style.color='lime';
</script>";
$ast="Approved";}


else if(isset($_POST["r"])&&empty($rdet['Approvel status'])){
echo "<script>
if(confirm('Sure,want to unapprove?'))
alert('unapproved');
document.getElementById('ca').style.color='red';
</script>";
$ast="Unapproved";}


if(!empty($ast)){
$con->query("UPDATE loyolite SET `Approvel status`='{$ast}' WHERE Deptno='{$rdet["Deptno"]}'");
//setcookie("rdet",serialize($rdet),time()+86400*30);
echo "<script>document.getElementById('tb').innerHTML=`<td><center><i><b>Approvel status</b></i></td><td><i id='ca'><b>{$rdet['Approvel status']}</b></i></center></td></tr>`;</script>";}

} //Function ends here


//Fetching from DB
$con=new mysqli("localhost","root","","loyola");
$res=$con->query("select * from loyolite");


//Fetching and sending a row of record for displaying.
foreach($res as $rdet)
display($rdet);
print_r($res);

//Back button
echo '<center><a href="mma.php">Back</a><br>
<br><button onclick="window.print()">Print</button></center>';

} 
else 
echo "<center><h2><i>Oops...!<br>It seems like No one registered yet..!</i></h2><br><a href='mma.php'>Home</a></center><br><br>";
?>
