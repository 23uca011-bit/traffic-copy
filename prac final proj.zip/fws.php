<html>
<head>
<tittle></tittle>
<style>
/* Reset default styles */
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

/* Body aesthetics */
body {
  background: linear-gradient(to right, #e0f7fa, #f1f8e9);
  color: #333;
  padding: 20px;
}

/* Center header */
h1 {
  font-size: 36px;
  color: #00796b;
  margin-bottom: 10px;
}

/* Login buttons */
#log button {
  margin: 10px;
  padding: 8px 16px;
  border: none;
  background-color: #004d40;
  color: white;
  border-radius: 5px;
  cursor: pointer;
}

#log button:hover {
  background-color: #00796b;
}

/* Fieldsets */
fieldset {
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 20px;
  margin: 10px;
  background-color: #ffffffdd;
}

/* Labels and inputs */
label {
  display: block;
  margin: 10px 0;
}

input, select, textarea {
  width: 95%;
  padding: 8px;
  border: 1px solid #aaa;
  border-radius: 5px;
}

/* Buttons */
input[type="submit"] {
  background-color: #00796b;
  color: white;
  font-weight: bold;
  padding: 10px 20px;
  border: none;
  margin-top: 10px;
  cursor: pointer;
  border-radius: 6px;
}

input[type="submit"]:hover {
  background-color: #004d40;
}

/* Headings */
h3, h6 {
  color: #004d40;
  margin-bottom: 10px;
}

/* Responsive */
@media screen and (max-width: 600px) {
  input, select, textarea {
    width: 100%;
  }

  fieldset {
    padding: 10px;
  }

  h1 {
    font-size: 28px;
  }
}

<!DOCTYPE html>
</style>
</head>
<body>
<center>
<h1><b><u>J J WATER SUPPLY</u></b></h1><br><br>
<div>
<fieldset id="log">
<b>LOGIN</b><br>
<button onclick="adlogin.php">Admin</button>
<button onclick="ulogin.php">User</button>
<button onclick="dlogin.php">Dealers</button>
</fieldset>
</div>
</center><br><br>
<div id="ulog">
<center>
<fieldset id="fulog">
<h3><u>Sign in</u></h3>
<label>Username: <input type="text" id="lun" name="lun" placeholder="User Name"></label><br><br>
<label>Password <input type="password" id="lup" name="lup" placeholder="Password"></label><br>
<label><small><i>remember me <input type="checkbox" id="rm"></i></small></label><br>
<a href="fpw.php"><small><i>forgot password</i></small></a>
</fieldset></center>
</div>
<div id="uregister">
    <fieldset id="furegister">
  <form method="post" action="" id="ulf">
    <b><h6><u>User Details</u></h6>
    <label>Name: <input type="text" id="un" name="un" placeholder="Your Name"></label><br><br>
    <label>Gender: </label>
    <label><input type="radio" id="ug" name="ug" value="Male">Male </label>
    <label><input type="radio" id="ug" name="ug" value="Female">Female</label>
    <label><input type="radio" id="ug" name="ug" value="Others">Others </label><br><br>
    <label>Email: <input type="email" id="ue" name="ue" placeholder="jack@.com"></label><br><br>
    <label>Phone no: <input type="number" id="up" name="up" placeholder="Contact no"></label><br><br>
    <label>Type: 
    <select id="ht" name="ht">
    <option value="Appartment">Appartment</option>
    <option value="Lodge">Lodge</option>
    <option value="Single house">Single house</option>
    <option value="Multiple house">Multiple house</option>
    <option value="Flats">Flats</option>
    </select></label><br><br>
    <label>Floor no: <input type="number" id="ufn" name="ufn" placeholder="0"></label><br><br>
    <label>Door no: <input type="number" id="udn" name="udn" placeholder="Door/Room no"></label><br><br>
    <label>Street: <input type="text" id="us" name="us" placeholder="Street Name"></label><br><br>
    <label>Area: <input type="text" id="ua" name="ua" placeholder="Area Name"></label><br><br>
    <label>Landmark: <input type="text" id="ulm" name="ulm" placeholder="Nearby"></label><br><br>
    <label>Address: <textarea id="uadd" name="uadd" ></textarea></label><br><br>
    <div id="nd">
    <h6><u>Neighbour details</u></h6>
    <label>Name: <input type="text" id="nn" name="nn" placeholder="Neighbour Name"></label><br><br>
    <label>Gender: </label>
    <label><input type="radio" id="ng" name="ng" value="Male">Male </label>
    <label><input type="radio" id="ng" name="ng" value="Female">Female</label>
    <label><input type="radio" id="ng" name="ng" value="Others">Others </label><br><br>
   <label>Phone no: <input type="number" id="np" name="np" placeholder="Neighbour's contact no"></label><br><br>
   <label>Address: <textarea id="nadd" name="nadd" ></textarea></label><br><br>   
</div>
<div id="cb">
<h6><u>Can Booking</u></h6>
<label>No.of.cans needed: <input type="number" id="unc" name="unc" placeholder="No of cans needed"></label><br><br>
<label>Service: </label><br>
    <label><input type="radio" id="ucs" name="ucs" value="Fill">Fill </label><br>
    <label><input type="radio" id="ucs" name="ucs" value="Wash&Fill">Wash and Fill</label><br><br>
<label>Available: <input type="datetime-local" id="udt" name="udt" ></label><br><br> 
   


</div>
<input type="submit" name="usb" id="usb" value="Register">
   </b>
  </form>
</fieldset>
</div>
<div id="upage"></div> -->

<?php
$ln=$_POST["lun"];
$lp=$_POST["lup"];
$n=$_POST["un"];
$g=$_POST["ug"];
$e=$_POST["ue"];
$p=$_POST["up"];
$t=$_POST["ht"];
$fn=$_POST["ufn"];
$dn=$_POST["udn"];
$st=$_POST["us"];
$a=$_POST["ua"];
$nn=$_POST["nn"];
$ng=$_POST["ng"];
$np=$_POST["np"];
$na=$_POST["nadd"];

if(isset($_POST["usb"])){
echo "<br><u><b>Login Details</u>".
"<br>User name:".$ln.
"<br>Password:".$lp.
"<br><br><u><b>User Details</u></b>".
"<br>Name:".$n.
"<br>Gender:".$g.
"<br>Email:".$e.
"<br>Phone no:".$p.
"<br>residential type:".$t.
"<br>Floor no:".$fn.
"<br>Door no:".$dn.
"<br>Street:".$st.
"<br>Area:".$a.
"<br><br><u><b>Neighbour Details</u></b>".
"<br>Name:".$nn.
"<br>Gender:".$ng.
"<br>Phone no:".$np.
"<br>Address:".$na;






}



?>
</body>
</html>