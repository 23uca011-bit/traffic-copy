<!DOCTYPE html>
<html>
<head>
<tittle></tittle>
</head>
<body>
<center>
<h1><b><u>J J WATER SUPPLY</u></b></h1><br><br>
<div>
<fieldset id="log">
<b>LOGIN</b><br>
<button onclick="adlogin.php">Admin</button>
<button onclick="ulogin.php">User</button>
<button onclick="dlogin.php">Dealers</button>
</fieldset>
</div>
</center><br><br>
<div id="ulog">
<center>
<fieldset id="fulog">
<h3><u>Sign in</u></h3>
<label>Username: <input type="text" id="lun" name="lun" placeholder="User Name"></label><br><br>
<label>Password <input type="password" id="lup" name="lup" placeholder="Password"></label><br>
<label><small><i>remember me <input type="checkbox" id="rm"></i></small></label><br>
<a href="fpw.php"><small><i>forgot password</i></small></a>
</fieldset></center>
</div>
<div id="uregister">
    <fieldset id="furegister">
  <form method="post" action="" id="ulf">
    <b><h6><u>User Details</u></h6>
    <label>Name: <input type="text" id="un" name="un" placeholder="Your Name"></label><br><br>
    <label>Gender: </label>
    <label><input type="radio" id="ug" name="ug" value="Male">Male </label>
    <label><input type="radio" id="ug" name="ug" value="Female">Female</label>
    <label><input type="radio" id="ug" name="ug" value="Others">Others </label><br><br>
    <label>Email: <input type="email" id="ue" name="ue" placeholder="jack@.com"></label><br><br>
    <label>Phone no: <input type="number" id="up" name="up" placeholder="Contact no"></label><br><br>
    <label>Type: 
    <select id="ht" name="ht">
    <option value="Appartment">Appartment</option>
    <option value="Lodge">Lodge</option>
    <option value="Single house">Single house</option>
    <option value="Multiple house">Multiple house</option>
    <option value="Flats">Flats</option>
    </select></label><br><br>
    <label>Floor no: <input type="number" id="ufn" name="ufn" placeholder="0"></label><br><br>
    <label>Door no: <input type="number" id="udn" name="udn" placeholder="Door/Room no"></label><br><br>
    <label>Street: <input type="text" id="usn" name="usn" placeholder="Street Name"></label><br><br>
    <label>Area: <input type="text" id="ua" name="ua" placeholder="Area Name"></label><br><br>
    <label>Landmark: <input type="text" id="ulm" name="ulm" placeholder="Nearby"></label><br><br>
    <label>Address: <textarea id="uadd" name="uadd" ></textarea></label><br><br>
    <div id="nd">
    <h6><u>Neighbour details</u></h6>
    <label>Name: <input type="text" id="nn" name="nn" placeholder="Neighbour Name"></label><br><br>
    <label>Gender: </label>
    <label><input type="radio" id="ng" name="ng" value="Male">Male </label>
    <label><input type="radio" id="ng" name="ng" value="Female">Female</label>
    <label><input type="radio" id="ng" name="ng" value="Others">Others </label><br><br>
   <label>Phone no: <input type="number" id="np" name="np" placeholder="Neighbour's contact no"></label><br><br>
   <label>Address: <textarea id="nadd" name="nadd" ></textarea></label><br><br>   
</div>
<div id="cb">
<h6><u>Can Booking</u></h6>
<label>No.of.cans needed: <input type="number" id="unc" name="unc" placeholder="No of cans needed"></label><br><br>
   


</div>
<input type="submit" name="usb" id="usb" value="Register">
   </b>
  </form>
</fieldset>
</div>
<div id="upage"></div> -->
</body>
</html>