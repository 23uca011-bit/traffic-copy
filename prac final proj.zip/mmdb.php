<?php
//DB creation
$con=new mysqli("localhost","root","");
$con->query("CREATE DATABASE IF NOT EXISTS loyola");
//DB connection
$con=new mysqli("localhost","root","","loyola");
$con->query("CREATE TABLE IF NOT EXISTS loyolite(S_no int auto_increment primary key,Name varchar(30),Dept_no varchar(10),Contact_no int(10),Adhar_no int(12),Address varchar(250),Mode_of_transport varchar(10),Distance varchar(3),Shift varchar(10),Status varchar(10),Reason varchar(250),Father_name varchar(25),Father_income int(10),Father_occupation varchar(25),Mother_name varchar(25),Mother_income int(10),Mother_occupation varchar(25),No_of_sibling int(5),Overall_income int(10),Passport_photo varchar(50),Ration_card varchar(50),Income_certificate varchar(50),Community_certificate varchar(50),Death_certificate varchar(50),Id_card varchar(50),Parent_letter varchar(50),Student_sign varchar(50),Faculty_letter varchar(50),HOD_permit varchar(50),Approvel_status varchar(15))"); 

?>



