<?php 
session_start();
$_SESSION["reg"]=0;

//declaring variable to store exception message.
$nerr=$eerr=$perr=$cperr=$mp=$gp="";

/*if($_SERVER["REQUEST_METHOD"]=="POST"&&isset($_POST["rb"])){
function sani($d){
$d=trim($d);
$d=stripslashes($d);
$d=htmlspecialchars($d);
return $d;}*/

//Validating function valf.
function valf(){
global $nerr,$eerr,$perr,$cperr;
$nerr=$eerr=$perr=$cperr="";
//Name
if(empty($_POST["rn"]))
$nerr="Name cannot be empty";
//Email
if(empty($_POST["re"]))
$eerr="Email cannot be empty";
//Password
$up=$_POST["rp"];
if(empty($up))
$perr="Password cannot be empty";
else if(strlen($up)<8||strlen($up)>8)
$perr="Password must contain 8 characters.";
else if(!(preg_match('/\d/',$up)&&preg_match('/[a-zA-Z]/',$up)&&preg_match('/[^a-zA-Z0-9]/',$up))) 
$perr="Password must contain a number,alphabet and symbol.";
//Confirm Password
if(empty($_POST["rcp"]))
$cperr="Confirm Password cannot be empty";
else if($_POST["rcp"]!=$_POST["rp"])
$cperr="Confirm Password must be same as Password.";

//Checking for error free
if(empty($nerr)&&empty($eerr)&&empty($perr)&&empty($cperr)){
//COOKIE(SIGNUP) storing inputs in a cookie.
$sudet=array(
"sn"=>$_POST["rn"],
"se"=>$_POST["re"],
"sp"=>$_POST["rp"]);
setcookie("sudet",serialize($sudet),time()+86400*30);
//Alert&Redirecting
echo "<script>alert('SUCCESSFULLY REGISTERED.'); 
window.location.href='mmlh.php';</script>";}

}
//Validating by calling the function.
if(isset($_POST["rb"]))
valf();
?>

<html>
<head>
<style>
.err{color:red;}
</style>
<script>
//js password generator
function dsp(){
alert('JESUS LOVES YOU');
function pgf(){
let gp="",parr=[Math.random()*10+48,Math.random()*26+65,Math.random()*15+33,Math.random()*26+98];
for(let i=parr.length-1;i>-1;i--){
let j=Math.floor(Math.random()*i);
[parr[i],parr[j]]=[parr[j],parr[i]];
gp+=String.fromCharCode(Math.floor(parr[i]));}
return gp;}
//new gp
let gp="";
gp=pgf()+pgf();
document.getElementById('rp').value=document.getElementById('rcp').value=gp;
alert('suggested password:\n'+gp);
document.getElementById('vp').innerHTML="<b><u><i>suggested password</i></u><br>"+gp;
}
</script>
</head>
<body><fieldset><center>
<form method="post" action="">
<h1><u><i>Sign up</i></u></h1><br>
<label>Name: <input type="text" id="rn" name="rn" placeholder="jack" maxlength="25" ></label><span class="err"> * <br><?php echo $nerr;?></span><br><br>
<label>Email: <input type="email" id="re" name="re" placeholder="jack12@gmail.com" ></label><span class="err"> * <br><?php echo $eerr;?></span><br><br>
<label>Password: <input type="password" id="rp" name="rp" placeholder="password" maxlength="8" ></label><span class="err"> * <br><?php echo $perr;?></span><br><br>
<label>Confirm Password: <input type="password" id="rcp" name="rcp" placeholder="confirm password" maxlength="8" ></label><span class="err"> * <br><?php echo $cperr;?></span><br>
<small><b><p id="vp"></p></b></small><br>
<button type="button" onclick="dsp()">Suggest Password</button><br>
<label><p>already have an account? <a href="mmlh.php">sigin</a></p></label>
<input type="submit" name="rb" id="rb" value="Sign up" ></center>
</form>
</fieldset>
</body>
</html>

