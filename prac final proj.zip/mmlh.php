<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
?>
<?php 
//signup validation
if(isset($_POST["s"])){

//SERIALIZE COOKIE(SIGNIN)
$sidet=array(
"n"=>$_POST["lun"],
"p"=>$_POST["lup"]);
setcookie("sidet",serialize($sidet),time()+3600*24);}

//UNSERIALIZE COOKIE(SIGNUP)
$sudet=unserialize($_COOKIE["sudet"]);

//declaring variable to store exception message.
$nerr=$perr=$cerr=$v="";

//Validating function valf.
function valf(){
global $nerr,$perr,$cerr,$sudet;
$nerr=$perr="";
//Name
if(empty($_POST["lun"]))
$nerr="User name cannot be empty";
else if($_POST["lun"]!=(isset($sudet["sn"])?$sudet["sn"]:""))
$nerr="incorrect user name.";
//Password
if(empty($_POST["lup"]))
$perr="Password cannot be empty";
else if($_POST["lup"]!=(isset($sudet["sp"])?$sudet["sp"]:""))
$perr="incorrect Password.";
//Captcha
if(empty($_POST["lc"]))
$cerr="Captcha cannot be empty";
else if($_POST["lc"]!=$_POST["cv"])
$cerr="incorrect Captcha.";
//Redirecting
if(empty($nerr)&&empty($perr)&&empty($cerr)){
echo "<script>alert('SUCCESSFULLY LOGGED-IN.')</script>"; 
if(isset($_SESSION["rol"])){
if($_SESSION["rol"]=="u")
echo "<script>window.location.href='mmhh.php';</script>";
else if($_SESSION["rol"]=="lh")
echo "<script>window.location.href='mmlh.php';</script>";
else if($_SESSION["rol"]=="a")
echo "<script>window.location.href='mma.php';</script>";}
else
echo "<script>window.location.href='mmhh.php';</script>";
}}
//Validation fun calling
if(isset($_POST["s"]))
valf();
//Sigup (html code)
if(!isset($_GET['fpp']))
echo "
<head>
<style>
.err{color:red;}
</style>
<script>
function pgf(){
let gp=\"\",parr=[Math.random()*10+48,Math.random()*26+65,Math.random()*15+33,Math.random()*26+98];
for(let i=parr.length-1;i>-1;i--){
let j=Math.floor(Math.random()*i);
[parr[i],parr[j]]=[parr[j],parr[i]];
gp+=String.fromCharCode(Math.floor(parr[i]));}
document.getElementById('c').innerText=gp;
document.getElementById('icv').value=gp;
document.getElementById('cv').value=gp;}
window.onload=pgf;
</script>
</head>
<body>".'
<fieldset id="fs"><center>
<form method="post" name="lf" id="lf" action="">
<h1><u>SIGIN</u></h1><br><br>
<label>Username: <input type="text" id="lun" name="lun" placeholder="User Name" maxlength="25"><span class="err"><br>'.$nerr.'</span></label><br><br>
<label>Password <input type="password" id="lup" name="lup" placeholder="Password"><span class="err"><br>'.$perr.'</span></label><br><br>
<label>Captcha: <input type="text" id="icv" name="icv" size=1.3 readonly><h5 id="c"></h5></label>
<input type="hidden" id="cv" name="cv">
<label>Enter Captcha:<input type="text" id="lc" name="lc" maxlength="4" size=4><span class="err"><br>'.$cerr.'</span></label><br><br>
<a href="?fpp=1" id="fp" name="fp" ><small><i>forgot password</i></small></a><br><br><a href="mmr.php"><small><i>Don\'t have an account? sigup</i></small></a><br><br>
<input type="submit" name="s" value="sigin">
</form><center>
</fieldset>
</body>';
//forgot password verification (html code)
if(isset($_GET['fpp'])){
$vnerr=$d="";
echo '
<style>
.err{color:red;}
</style><center>
<fieldset id="fs">
<form method="post" name="lf" id="lf" action="">
<h1><u><i>Verification</i></u></h1><br><br>
<label><small>Enter Phone or Email: </small>
<input type="text" id="vui" name="vui" placeholder="Enter Phone/Email" maxlength="40"></label>
<input type="submit" name="vs" value="Next">';
//forgot password verification (php code)
if(isset($_POST["vs"])){
//$otp=rand(0,9).rand(0,9).rand(0,9).rand(0,9);
$otp=(int)rand(1000,9999);
$_SESSION["o"]=$otp;
$_SESSION["vsb"]=isset($_POST["vs"]);
$v=isset($_POST["vui"])?$_POST["vui"]:"";
if(empty($v))
$vnerr="Please Enter Phone/Email.";
else{
if(preg_match('/^\d+$/',$v)){ //(\d means only one digit but \d+ means it can be n size digit, u can also use ctype_digit(),is_numeric() but this includes decimal values.)
if(strlen($v)!=10)
$vnerr="Phone no must be 10 nos";
else
$pt=substr($v,0,2).'*****'.substr($v,-1,3).' phone';
$d="<br><h3>Phone no ".$v."</h3>";
}
else if(preg_match('/@gmail.com$/',$v)){
if(!filter_var($v,FILTER_VALIDATE_EMAIL))
$vnerr="Incorrect Email id";
else{
require 'vendor\autoload.php';
//server settings
$m=new PHPMailer();
$m->isSMTP(true);
$m->Host='smtp.gmail.com';
$m->SMTPAuth=true;
$m->Username='phptest916@gmail.com';
$m->Password='zowb mxza yefo snbs';
$m->SMTPSecure=PHPMailer::ENCRYPTION_SMTPS;
//$m->SMTPDebug=SMTP::DEBUG_SERVER;
$m->Port=465;
$m->isHTML(true);
$m->setFrom('phptest916@gmail.com','jj');
$m->addAddress($_POST["vui"]);
$m->addReplyTo('phptest916@gmail.com');
$m->Body='<h1><i>Verification Mail</i></h1><br> your one time password(otp) is '.$_SESSION["o"].' <b>';
$m->send();
//echo "<br><br><h1>Mail sent</h1>";
$pt=substr($v,0,1).'*****'.(substr($v,-13,3)!=substr($v,0,3)?substr($v,-13,3):"").' gmail account';}
$d="<br><h3>Email ".$v."</h3>";
}
else{
$vnerr="Invalid";
$d="<br><h3>Invalid Entry ".$v."</h3>";}
}
echo '<br><span class="err"><br>'.$vnerr.'</span></label>'.$d.'</form>';
//redirecting to mmnpc.php
if(empty($vnerr)){
$_SESSION["otp"]=$otp;
$oerr="";
echo '<form method="post" action=""><br><label><small>Enter OTP: </small>
<input type="number" id="vuo" name="vuo" placeholder="otp here"></label>
<input type="submit" name="os" value="Next">
<br><br><br><b><i><p id="o">otp is sent to '.$pt.'.<br><br>Kindly check and enter it.</i>'.'</p></b></form></fieldset></center>';}}
if(isset($_POST["os"])){
if($_POST["vuo"]==$_SESSION["otp"])
echo "<script>window.location='mmnpc.php';</script>";
else if(empty($_POST["vuo"]))
echo "<script>alert('otp cant be empty Please try again now..')</script>";
else if($_POST["vuo"]!=$otp)
echo "<script>alert('incorrect otp Please try again now..')</script>";
}
}
?>














