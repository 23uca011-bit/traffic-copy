<!DOCTYPE html>
<html>
<head>
<style>
h3,h5{text-align: center;}  
</style>
<tittle></tittle>
</head>
<body>
<center>
<h1><b><u>M M REGISTERY</u></b></h1><br>
</center>
<div id="mmregister">
    <form method="post" action="" id="mmf" enctype="multipart/form-data">
    <fieldset id="fmregister">
    <b>
    <center><h2><u>Applicant Details</u></h2></center>
    <div id="sd">
    <h5><u>Student Details</u></h5>
    <label>Department no: <input type="text" id="udn" name="udn" placeholder="23-UCA-024"></label><br><br>
    <label>Phone no: <input type="number" id="up" name="up" placeholder="Contact no"></label><br><br>
    <label>Address: <textarea id="uadd" name="uadd" ></textarea></label><br><br>
    Mode of Transport: <select id="umot" name="umot">
    <option value="Train">Train</option>
    <option value="Bus">Bus</option>
    <option value="Car">Car</option>
    <option value="Bike">Bike</option>
    <option value="Bicycle">Bicycle</option>
    <option value="Walk">Walk</option>
    <option value="Bus&Train">Bus&Train</option>
    </select><br><br>
    <label>Distance: <input type="number" id="ud" name="ud" placeholder="in km"></label><br><br>
    <label>Status: </label>
    <label><input type="radio" id="us" name="us" value="Orphan">Orphen </label>
    <label><input type="radio" id="us" name="us" value="Semi-Orphen">Semi-Orphen </label>
    <label><input type="radio" id="us" name="us" value="None">None </label><br><br>
    <label>Reason: <textarea id="ur" name="ur" ></textarea></label><br><br>
    <hr></div>
    <div id="fd">
    <h5><u>Family Details</u></h5>
    <label>Father: <input type="text" id="ufn" name="ufn" placeholder="Name"> <input type="number" id="ufi" name="ufi" placeholder="Income"></label><br><br>
    <label>Mother: <input type="text" id="umn" name="umn" placeholder="Name"> <input type="number" id="umi" name="umi" placeholder="Income"></label><br><br>
    <label>Siblings: <input type="number" id="uns" name="uns" placeholder="No.of.siblings"></label><br><br>
    Overall Income: <p id="oi"></p><hr></div>
    <div id="dd">
    <h5><u>Documents</u></h5>
    <label>Ration card: <input type="file" id="urf" name="urf"></label><br><br>
    <label>Income certificate: <input type="file" id="uif" name="uif"></label><br><br>
    <label>Community certificate: <input type="file" id="ucf" name="ucf"></label><br><br>
    <label>Death certificate(if applicable): <input type="file" id="udf" name="udf"></label><br><br>
    <label>Id card: <input type="file" id="uidf" name="uidf"></label><br><br>
    <label>Passport photo: <input type="file" id="upf" name="upf"></label><br><br>
    <hr></div>
    <div id="fr"> 
    <h5><u>Faculty Recommendation</u></h5>
    <label>Recommend Letter: <input type="file" id="ufl" name="ufl"></label>
    <br><br><hr></div>
    <div id="hp"> 
    <h5><u>H.O.D Recommendation</u></h5>
    <label>Permit Letter: <input type="file" id="upl" name="upl"></label>
    </div><br><br>
        
  <!--  <table border="2px" id="ut">
    <thead id="uth">
    <tr>
    <th>S.No</th>
    <th>Parent Details</th>
    <th>Parent Name</th>
    <th>Parent Income</th>
    <th>Overall Income</th>
    </tr>
    </thead>
    <tbody id="utd">
    </tbody>
    </table> -->
     <input type="submit" name="usb" id="usb" value="Register">
   </b>
  </form>
</fieldset>
</form>
</div>
<div id="op">
<?php
echo "<h3><u>Dashboard</u></h3>";
if(isset($_POST["usb"])){
function fun(){
$dn=$_POST["udn"];$pn=$_POST["up"];
$add=$_POST["uadd"];$mot=$_POST["umot"];
$d=$_POST["ud"];$s=$_POST["uns"];
$r=$_POST["ur"];$p=$_POST["up"];
$fn=$_POST["ufn"];$mn=$_POST["umn"];
$fi=$_POST["ufi"];$mi=$_POST["umi"];
$ns=$_POST["uns"];


//METHOD TO UPLOAD FILE
function ful($fn){
if (($_SERVER['REQUEST_METHOD'] == 'POST')&&($_FILES[$fn]["error"]==UPLOAD_ERR_OK))
{
$td = "uploads/";
if (!file_exists($td)) 
mkdir($td, 0777, true);
$f = $_FILES[$fn];
$tf = $td . basename($f["name"]);
$ft = strtolower(pathinfo($tf, PATHINFO_EXTENSION));
$ck = getimagesize($f["tmp_name"]);
if ($ck === false) {
echo "❌ File is not an image.";
exit;}
$at = ['jpg', 'jpeg', 'png', 'gif'];
if (!in_array($ft, $at)) {
echo "❌ Only JPG, JPEG, PNG & GIF files are allowed.";
exit;}
return (move_uploaded_file($f["tmp_name"], $tf)?"<br><img src='$tf' alt='Uploaded Image' style=' width: 100%;
  max-width: 400px; height: auto;
  border: 1px solid #ccc;
  margin: 8px 0;'>":"Upload error");}}
echo "<br><b> Deptno: ".$dn."<br>Phone no: ".$p."<br>Address: ".$add."<br>Mode of Transport: ".$mot."<br>Distance: ".$d."<br>Status: ".$s."<br>Reason: ".$r
."<br>Father Name: ".$fn."<br>Father Income: ".$fi."<br>Mother name: ".$mn."<br>Mother Income: ".$mi."<br>Siblings: ".$ns."<br>Overall Income: ".((int)$fi+(int)$mi)."<br>Passort Photo: ".ful("upf")."<br>Ration card: ".ful("urf")."<br>Income certificate: ".ful("uif")."<br>Community certificate: ".ful("ucf")."<br>Death certificate: ".ful("udf")."<br>Id card: ".ful("uidf")."<br>Faculty letter: ".ful("ufl")."<br>H.O.D Permit: ".ful("upl")."</b>";}

fun();


    


    }
?>
</div>
</body>
</html>