<?php
$sidet=unserialize($_COOKIE["sidet"]);
echo "<h1>Sigin</h1>username: ".$sidet["n"]."<br>password: ".$sidet["p"];
$sudet=unserialize($_COOKIE["sudet"]);
echo "<h1>sigup</h1>username: ".$sudet["sn"]."<br>email: ".$sudet["se"]."<br>password: ".$sudet["sp"];
$rdet=unserialize($_COOKIE["rdet"]);
echo "<h1>Registered Details</h1>";
//new
echo "<h3>new</h3>";
foreach($rdet as $v){
if(is_array($v)){
foreach($v as $vv)
echo $vv."<br>";}
else
echo $v."<br>";}


echo "<br><h1>Request Box</h1><br>";
$rbdet=unserialize($_COOKIE["rbdet"]);
foreach($rbdet as $v){
if(is_array($v)){
foreach($v as $dd)
echo $dd."<br>";}
else
echo $v."<br>";}


?>