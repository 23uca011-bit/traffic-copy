<?php
// You can add PHP logic here if needed
$message = "Are you sure you want to proceed?";
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Confirmation Message</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0; padding: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      background-color: #f2f2f2;
    }

    .message-box {
      background: #fff;
      padding: 20px;
      max-width: 90%;
      width: 300px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      text-align: center;
    }

    .message-box button {
      margin-top: 15px;
      padding: 10px 20px;
      background-color: #007bff;
      border: none;
      color: white;
      border-radius: 4px;
      cursor: pointer;
      font-size: 16px;
    }

    .message-box button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>

<div class="message-box">
  <p><?php echo htmlspecialchars($message); ?></p>
  <form method="post" action="confirmed.php">
    <button type="submit">Confirm</button>
  </form>
</div>

</body>
</html>

