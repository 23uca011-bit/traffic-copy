<?php
session_start();
?>

<html>
<head>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  background-color: #333;
}

li {
  float: left;
}

li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover:not(.active) {
  background-color: #111;
}

.active {
  background-color: red;
}
</style>
<script>
function redir(){
alert('It seems that you arn\'t registered yet...Kindly register to visit the page');
let r="<?php echo json_encode(isset($_COOKIE["rct"]));?>";
if (r)
alert("Already registered!");
else 
window.location.href = "abth.php";
alert(r);
return r;
}
</script>
</head>
<body>
<h1>Hi<?php 
//COOKIE(SIGNIN)UNSERIALIZE
$sidet=unserialize($_COOKIE["sidet"]);
echo " , Welcome to our page ".(isset($sidet["n"])?$sidet["n"]:"");?></h1>
<br><br>
<ul>
<li><a class="active" href="#home" onclick="return false;">Home</a></li>
<li><a href="pracmmh.php">Register</a></li>
<li><a href="mmph.php" >Profile</a></li>
<li><a href="#contact">Contact</a></li>
<li><a href="abth.php">About</a></li>
<li><a href="mmc.php">Take Action</a></li>
<li>
<a href="#" 
onclick="if (confirm('Sure, do you want to logout?')) window.location='mmlop.php';return false;">
Logout
</a>
</li>
</ul>
</body>
</html>
<br> <a href="dum.php">dum</a>

